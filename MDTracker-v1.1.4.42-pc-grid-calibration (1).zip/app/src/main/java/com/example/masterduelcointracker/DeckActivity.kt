package com.example.masterduelcointracker

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.Bitmap
import android.os.Bundle
import android.view.Gravity
import android.util.LruCache
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.android.gms.tasks.Tasks
import java.util.Locale
import java.net.HttpURLConnection
import java.net.Proxy
import java.net.URL
import java.net.URLEncoder
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors


private object KoreanCardNames {
    // Commonly searched cards. Unknown names remain searchable by English name.
    private val names = linkedMapOf(
        "Ame no Habakiri no Mitsurugi" to "아메노하바키리노미츠루기",
        "Mitsurugi no Kensei" to "미츠루기권청",
        "Ash Blossom & Joyous Spring" to "하루 우라라",
        "Ghost Belle & Haunted Mansion" to "저택 와라시",
        "Effect Veiler" to "이펙트 뵐러",
        "Maxx \"C\"" to "증식의 G",
        "Infinite Impermanence" to "무한포영",
        "Called by the Grave" to "墓穴의 지명자",
        "Crossout Designator" to "말살의 지명자",
        "Nibiru, the Primal Being" to "원시생명체 니비루",
        "Droll & Lock Bird" to "드롤 & 로크 버드",
        "Dimension Shifter" to "디멘션 어트랙터",
        "Mulcharmy Fuwalos" to "마루챠미 후와로스",
        "Mulcharmy Purulia" to "마루챠미 푸루리아",
        "Mulcharmy Meowls" to "마루챠미 메울스",
        "Dark Magician" to "블랙 매지션",
        "Blue-Eyes White Dragon" to "푸른 눈의 백룡",
        "Red-Eyes Black Dragon" to "붉은 눈의 흑룡",
        "Pot of Prosperity" to "욕망과 졸부의 항아리",
        "Pot of Desires" to "욕망의 항아리",
        "Pot of Extravagance" to "졸부와 겸허의 항아리",
        "Raigeki" to "번개",
        "Harpie's Feather Duster" to "해피의 깃털",
        "Monster Reborn" to "죽은 자의 소생",
        "Lightning Storm" to "라이트닝 스톰",
        "Evenly Matched" to "길항승부",
        "Solemn Judgment" to "신의 심판",
        "Solemn Strike" to "신의 통고",
        "Triple Tactics Talent" to "삼전의 재",
        "Triple Tactics Thrust" to "삼전의 호",
        "Forbidden Droplet" to "금지된 일적",
        "Dark Ruler No More" to "명왕결계파",
        "Super Polymerization" to "초융합",
        "Polymerization" to "융합",
        "Ashened to Endlessness" to "잿빛의 종언",
        "S:P Little Knight" to "S:P 리틀나이트",
        "Accesscode Talker" to "액세스코드 토커",
        "Apollousa, Bow of the Goddess" to "소명의 신궁-아폴로우사",
        "Baronne de Fleur" to "플뢰르 드 바로네스",
        "Borreload Savage Dragon" to "바렐로드 새비지 드래곤",
        "Chaos Angel" to "카오스 앙헬-혼돈의 쌍익-",
        "Divine Arsenal AA-ZEUS - Sky Thunder" to "천옥의 왕 아제우스",
        "Underworld Goddess of the Closed World" to "닫힌 세계의 명신",
        "Accesscode Talker" to "액세스코드 토커",
        "Nibiru, the Primal Being" to "원시생명체 니비루",
        "D.D. Crow" to "D.D. 크로우",
        "Ghost Ogre & Snow Rabbit" to "유령토끼",
        "PSY-Framegear Gamma" to "PSY프레임기어 감마",
        "Called by the Grave" to "무덤의 지명자",
        "Ash Blossom & Joyous Spring" to "하루 우라라",
        "Nibiru, the Primal Being" to "원시생명체 니비루",
        "Monster Reborn" to "죽은 자의 소생",
        "Dark Hole" to "블랙홀",
        "Book of Moon" to "달의 서",
        "Cosmic Cyclone" to "코즈믹 싸이크론",
        "Pot of Avarice" to "탐욕의 항아리",
        "Swords of Revealing Light" to "빛의 봉인검",
        "Terraforming" to "테라포밍",
        "Foolish Burial" to "어리석은 매장",
        "One for One" to "원 포 원",
        "Reinforcement of the Army" to "증원",
        "Skill Drain" to "스킬 드레인",
        "There Can Be Only One" to "군웅할거",
        "Anti-Spell Fragrance" to "마법 봉인의 방향제",
        "Evenly Matched" to "길항승부",
        "Lightning Storm" to "라이트닝 스톰",
        "Forbidden Droplet" to "금지된 일적",
        "Effect Veiler" to "이펙트 뵐러",
        "Droll & Lock Bird" to "드롤 & 로크 버드",
        "Dimension Shifter" to "디멘션 어트랙터",
        "Maxx \"C\"" to "증식의 G"
    )
    private val aliases = names.entries.associate { it.value.lowercase() to it.key }
    fun englishFor(query: String): String {
        val q = query.trim()
        names.entries.firstOrNull { it.value.equals(q, ignoreCase = true) }?.let { return it.key }
        names.entries.firstOrNull { it.value.contains(q, ignoreCase = true) && q.length >= 2 }?.let { return it.key }
        return q
    }
    fun display(english: String): String = names.entries.firstOrNull { it.key.equals(english.trim(), ignoreCase = true) }?.value ?: english
    fun koreanType(type: String): String {
        val raw = type.trim()
        if (raw.isEmpty()) return "카드"
        val t = raw.lowercase()

        // Spell and Trap cards have one primary subtype; do not append generic labels.
        if (t.contains("spell card") || t == "spell") {
            val subtype = when {
                t.contains("quick-play") -> "속공 마법"
                t.contains("continuous") -> "지속 마법"
                t.contains("equip") -> "장착 마법"
                t.contains("field") -> "필드 마법"
                t.contains("ritual") -> "의식 마법"
                else -> "일반 마법"
            }
            return subtype
        }
        if (t.contains("trap card") || t == "trap") {
            return when {
                t.contains("counter") -> "카운터 함정"
                t.contains("continuous") -> "지속 함정"
                else -> "일반 함정"
            }
        }

        val parts = mutableListOf<String>()
        if (t.contains("token")) parts += "토큰"
        if (t.contains("pendulum")) parts += "펜듈럼"

        // Pick the monster's primary category, while retaining every applicable subtype.
        val primary = when {
            t.contains("link") -> "링크 몬스터"
            t.contains("xyz") -> "엑시즈 몬스터"
            t.contains("synchro") -> "싱크로 몬스터"
            t.contains("fusion") -> "융합 몬스터"
            t.contains("ritual") -> "의식 몬스터"
            t.contains("normal") -> "일반 몬스터"
            t.contains("effect") -> "효과 몬스터"
            t.contains("monster") -> "몬스터"
            else -> ""
        }
        if (primary.isNotEmpty()) parts += primary
        if (t.contains("tuner")) parts += "튜너"
        if (t.contains("flip")) parts += "리버스"
        if (t.contains("gemini")) parts += "듀얼"
        if (t.contains("spirit")) parts += "스피릿"
        if (t.contains("union")) parts += "유니온"
        if (t.contains("toon")) parts += "툰"
        if (t.contains("pendulum") && primary.isEmpty()) parts += "펜듈럼 몬스터"

        return parts.distinct().joinToString("/").ifBlank { raw }
    }
}

class DeckActivity : Activity() {
    private val executor = Executors.newFixedThreadPool(3)
    @Volatile private var bundledKoreanCardsCache: List<JSONObject>? = null
    private val imageCache = LruCache<String, android.graphics.Bitmap>(24)
    private val cards = mutableListOf<DeckCard>()
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var search: EditText
    private lateinit var results: LinearLayout
    private lateinit var deckList: LinearLayout
    private val deckImageRequestCode = 7314
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(s: String, size: Float = 14f) = TextView(this).apply { text=s; textSize=size; setTextColor(Color.rgb(28,35,48)) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val saved = DeckRepository.load(this).filterNot {
            it.type.contains("토큰") || it.type.contains("token", true) || it.name.contains("token", true)
        }
        // Repair previously saved cards against the bundled, password-keyed catalogue.
        // This also migrates cards that were stored in the wrong deck section by older builds.
        val bundledRows = loadBundledKoreanCards()
        val bundledByPassword = bundledRows.filter { it.optString("password").isNotBlank() }
            .associateBy { it.optString("password") }
        val bundledByName = bundledRows.associateBy {
            normalizeCardTypeKey(it.optString("en_name").ifBlank { it.optString("title") })
        }
        val repairedSaved = saved.map { card ->
            val row = (if (card.id > 0) bundledByPassword[card.id.toString()] else null)
                ?: bundledByName[normalizeCardTypeKey(card.name)]
            if (row == null) card.copy(section = sectionForType(card.type)) else {
                val type = classifyDetailedType(row, row.optString("types").ifBlank { "카드" })
                card.copy(type = type, section = sectionForType(type),
                    localizedName = row.optString("ko_name").ifBlank { card.localizedName },
                    effect = cleanCardText(row.optString("ko_text")).ifBlank { card.effect },
                    level = row.optString("level").ifBlank { card.level })
            }
        }
        // Keep old saved decks from bypassing the limit rules after an app update.
        val accepted = mutableListOf<DeckCard>()
        for (card in repairedSaved) {
            val limit = cardLimit(card)
            val key = normalizedCardName(card.name)
            val already = accepted.count { normalizedCardName(it.name) == key }
            val sectionCount = accepted.count { it.section == card.section }
            if (limit > already && (card.section != "MAIN" || sectionCount < 60) &&
                (card.section != "EXTRA" || sectionCount < 15)) accepted.add(card)
        }
        // Persist the corrected sections immediately so future launches keep the repair.
        if (accepted != saved) DeckRepository.save(this, accepted)
        cards.addAll(accepted)
        render()
    }

    private fun render() {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(12),dp(8),dp(12),dp(8)); setBackgroundColor(Color.rgb(245,247,250)) }
        val title = label("덱 빌더", 24f).apply { setTypeface(null, Typeface.BOLD) }
        root.addView(title)
        root.addView(label("Master Duel 금제 (2026-10-06) · 금지 0 / 제한 1 / 준제한 2 / 무제한 3", 13f))
        root.addView(label("메인 40~60장 · 엑스트라 0~15장 · 금제는 카드명 기준으로 적용", 12f))
        root.addView(label("카드 종류에 따라 메인 덱 / 엑스트라 덱에 자동으로 배치됩니다.", 12f))
        root.addView(Button(this).apply {
            text = "사진으로 덱 레시피 불러오기"
            setOnClickListener { openDeckRecipeImage() }
        }, LinearLayout.LayoutParams(-1, dp(46)))
        val searchRow = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        search = EditText(this).apply {
            hint = "카드명 또는 카드군 검색"
            setSingleLine(true)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { _, actionId, event ->
                val enterPressed = event?.keyCode == android.view.KeyEvent.KEYCODE_ENTER &&
                    event.action == android.view.KeyEvent.ACTION_DOWN
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH || enterPressed) {
                    searchCards()
                    true
                } else false
            }
        }
        searchRow.addView(search, LinearLayout.LayoutParams(0,dp(52),1f))
        searchRow.addView(Button(this).apply { text="검색"; setOnClickListener { searchCards() } }, LinearLayout.LayoutParams(dp(76),dp(48)))
        root.addView(searchRow)
        status = label("카드명 또는 카드군을 검색한 뒤 + 버튼으로 덱에 추가하세요.",12f); root.addView(status)
        val scroll = ScrollView(this); results = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }; scroll.addView(results)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        root.addView(label("내 덱",18f).apply { setTypeface(null,Typeface.BOLD) })
        val deckScroll=ScrollView(this); deckList=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }; deckScroll.addView(deckList)
        root.addView(deckScroll,LinearLayout.LayoutParams(-1,dp(190)))
        val bottom=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        bottom.addView(Button(this).apply { text="저장"; setOnClickListener { saveDeck() } },LinearLayout.LayoutParams(0,dp(48),1f))
        bottom.addView(Button(this).apply { text="덱 초기화"; setOnClickListener { AlertDialog.Builder(this@DeckActivity).setMessage("현재 덱을 모두 비울까요?").setNegativeButton("취소",null).setPositiveButton("비우기"){_,_->cards.clear();saveDeck()} .show() } },LinearLayout.LayoutParams(0,dp(48),1f))
        root.addView(bottom); setContentView(root); renderDeck()
    }

    private fun openDeckRecipeImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, deckImageRequestCode)
    }

    @Deprecated("Uses the platform document picker for compatibility with the current project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != deckImageRequestCode || resultCode != RESULT_OK) return
        val uris = mutableListOf<Uri>()
        data?.clipData?.let { clip ->
            for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let(uris::add)
        }
        if (uris.isEmpty()) data?.data?.let(uris::add)
        if (uris.isEmpty()) return
        status.text = "${uris.size}장의 사진에서 왼쪽 덱 영역을 분석하는 중…"
        results.removeAllViews()
        executor.execute {
            try {
                val aggregate = linkedMapOf<String, RecipeCandidate>()
                val artworkRows = mutableListOf<List<ArtworkFingerprint>>()
                var processed = 0
                for (uri in uris) {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                    val sample = maxOf(1, Integer.highestOneBit(maxOf(bounds.outWidth, bounds.outHeight) / 2200))
                    val options = BitmapFactory.Options().apply { inSampleSize = sample }
                    val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
                        ?: continue
                    try {
                        if (!isDesktopDeckScreenshot(bitmap)) {
                            throw IllegalArgumentException("PC판 10열 덱 리스트 캡처만 지원합니다. 모바일 덱 화면 인식 경로는 비활성화되어 있습니다.")
                        }
                        val scan = recognizeDeckRecipe(bitmap)
                        artworkRows.addAll(scan.artworkRows)
                        scan.candidates.forEach { candidate ->
                            val key = if (candidate.card.id > 0) "id:${candidate.card.id}"
                                else "name:${normalizeOcrText(candidate.card.name)}"
                            val old = aggregate[key]
                            if (old == null || candidate.quantity > old.quantity) aggregate[key] = candidate
                        }
                        processed++
                    } finally { bitmap.recycle() }
                }
                // First use the precomputed full-catalog visual index when it is bundled.
                // OCR remains a supplementary signal, not a prerequisite for image matching.
                val uniqueArtworkRows = mutableListOf<List<ArtworkFingerprint>>()
                artworkRows.forEach { row ->
                    val repeated = uniqueArtworkRows.any { prior ->
                        row.size == prior.size && row.indices.count { artworkSimilarity(row[it], prior[it]) >= 90 } >= minOf(4, row.size)
                    }
                    if (!repeated) uniqueArtworkRows.add(row)
                }
                val visualMatches = ArtworkCatalogIndex.identify(
                    this@DeckActivity,
                    uniqueArtworkRows.flatten().map { it.vector }
                )
                for ((databaseId, result) in visualMatches) {
                    val card = deckCardForDatabaseId(databaseId) ?: continue
                    val key = "id:${card.id}"
                    val old = aggregate[key]
                    if (old == null) {
                        aggregate[key] = RecipeCandidate(card, result.first.coerceIn(1, 3), 0, result.second)
                    } else {
                        old.quantity = maxOf(old.quantity, result.first.coerceIn(1, 3))
                        old.artworkScore = maxOf(old.artworkScore, result.second)
                    }
                }
                val found = aggregate.values.sortedByDescending { it.confidence + it.artworkScore }.take(100)
                // Candidate-only downloads remain as a fallback for builds without the full index.
                if (ArtworkCatalogIndex.entries(this@DeckActivity).isEmpty()) {
                    cacheCroppedArtForCandidates(found)
                    scoreCandidatesByArtwork(found, artworkRows)
                }
                val rankedFound = found.sortedByDescending { it.combinedScore }
                runOnUiThread {
                    if (rankedFound.isEmpty()) {
                        status.text = "${processed}장 분석 완료: 왼쪽 덱 영역에서 카드명을 찾지 못했습니다."
                    } else {
                        status.text = "${processed}장 분석 완료 · ${rankedFound.size}종 후보. 일러스트 점수는 OCR 후보와 시각적 유사도를 비교한 참고값입니다."
                        showRecognizedDeckCandidates(rankedFound)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "이미지 처리 실패: ${e.message ?: e.javaClass.simpleName}" }
            }
        }
    }

    /**
     * Master Duel deck editor screenshots place the deck recipe in the left panel.
     * Deliberately crop only that panel; the right-side card browser is excluded.
     */
    private fun isDesktopDeckScreenshot(source: Bitmap): Boolean =
        source.width >= 1000 && source.height >= 900 && source.width.toFloat() / source.height >= 0.72f

    private fun cropDeckRecipePanel(source: Bitmap): Bitmap {
        require(isDesktopDeckScreenshot(source)) {
            "PC판 10열 덱 리스트 캡처만 지원합니다. 모바일 덱 화면 인식은 사용하지 않습니다."
        }
        // PC screenshot: the deck list occupies almost the entire canvas width.
        val left = (source.width * 0.012f).toInt().coerceIn(0, source.width - 1)
        val top = (source.height * 0.105f).toInt().coerceIn(0, source.height - 1)
        val right = (source.width * 0.985f).toInt().coerceIn(left + 1, source.width)
        val bottom = (source.height * 0.975f).toInt().coerceIn(top + 1, source.height)
        return Bitmap.createBitmap(source, left, top, right - left, bottom - top)
    }

    private data class RecipeScanResult(
        val candidates: List<RecipeCandidate>,
        val artworkRows: List<List<ArtworkFingerprint>>
    )

    private data class ArtworkFingerprint(val vector: FloatArray)

    private fun recognizeDeckRecipe(bitmap: Bitmap): RecipeScanResult {
        val rows = extractDeckArtworkRows(bitmap)
        val panel = cropDeckRecipePanel(bitmap)
        val image = InputImage.fromBitmap(panel, 0)
        val korean = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        val latin = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        return try {
            val koreanText = Tasks.await(korean.process(image))
            val latinText = Tasks.await(latin.process(image))
            val lines = linkedSetOf<String>()
            koreanText.textBlocks.forEach { block -> block.lines.forEach { lines.add(it.text) } }
            latinText.textBlocks.forEach { block -> block.lines.forEach { lines.add(it.text) } }
            RecipeScanResult(matchOcrLinesToCards(lines.toList()), rows)
        } finally {
            korean.close()
            latin.close()
            panel.recycle()
        }
    }

    /**
     * Download cropped reference artwork only for cards identified in the left deck panel.
     * Files are cached once in app-private storage and reused on later imports.
     */
    private val artworkManifest by lazy {
        runCatching {
            val json = assets.open("artwork_manifest_index.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            JSONObject(json)
        }.getOrNull()
    }

    private fun manifestArtworkUrls(cardId: Int): List<String> {
        val artworks = artworkManifest?.optJSONObject(cardId.toString()) ?: return emptyList()
        val urls = mutableListOf<String>()
        val keys = artworks.keys()
        while (keys.hasNext()) {
            val item = artworks.optJSONObject(keys.next()) ?: continue
            // Prefer Korean card renders; fall back to the highest-resolution available art.
            listOf(item.optString("ko"), item.optString("best")).forEach { path ->
                if (path.isBlank()) return@forEach
                val address = when {
                    path.startsWith("//") -> "https:$path"
                    path.startsWith("/") -> "https://artworks.ygoresources.com$path"
                    else -> path
                }
                if (address !in urls) urls += address
            }
        }
        return urls
    }

    private fun downloadImage(address: String, target: File): Boolean {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(address).openConnection(Proxy.NO_PROXY) as HttpURLConnection).apply {
                connectTimeout = 10000
                readTimeout = 15000
                requestMethod = "GET"
                instanceFollowRedirects = true
            }
            if (connection.responseCode != HttpURLConnection.HTTP_OK) return false
            connection.inputStream.use { input -> FileOutputStream(target).use { output -> input.copyTo(output) } }
            target.length() > 0L
        } catch (_: Exception) {
            target.delete()
            false
        } finally { connection?.disconnect() }
    }

    private fun cropManifestCardRender(sourceFile: File, target: File): Boolean {
        val bitmap = BitmapFactory.decodeFile(sourceFile.absolutePath) ?: return false
        return try {
            // Manifest files may be full card renders or artwork-only images. Crop the
            // illustration window only for portrait card-shaped renders.
            val aspect = bitmap.height.toFloat() / bitmap.width.toFloat()
            val crop = if (aspect > 1.18f) {
                val left = (bitmap.width * 0.055f).toInt()
                val top = (bitmap.height * 0.135f).toInt()
                val right = (bitmap.width * 0.945f).toInt().coerceAtLeast(left + 1)
                val bottom = (bitmap.height * 0.735f).toInt().coerceAtLeast(top + 1)
                Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
            } else bitmap
            try {
                FileOutputStream(target).use { output ->
                    if (!crop.compress(Bitmap.CompressFormat.JPEG, 92, output)) return false
                }
                target.length() > 0L
            } finally { if (crop !== bitmap) crop.recycle() }
        } finally { bitmap.recycle() }
    }

    private fun cacheCroppedArtForCandidates(found: List<RecipeCandidate>) {
        val directory = File(filesDir, "ygoprodeck_cropped_cache")
        if (!directory.exists()) directory.mkdirs()
        val rawDirectory = File(filesDir, "manifest_artwork_cache")
        if (!rawDirectory.exists()) rawDirectory.mkdirs()
        found.filter { it.card.id > 0 }.forEach { candidate ->
            val target = File(directory, "${candidate.card.id}.jpg")
            if (target.exists() && target.length() > 0L) return@forEach
            // Keep the existing cropped-image source as the fastest path.
            val ygopro = "https://images.ygoprodeck.com/images/cards_cropped/${candidate.card.id}.jpg"
            if (downloadImage(ygopro, target)) return@forEach
            target.delete()
            // Fallback to the supplied Konami artwork manifest, keyed by the shared card ID.
            val raw = File(rawDirectory, "${candidate.card.id}.img")
            val downloaded = raw.exists() && raw.length() > 0L ||
                manifestArtworkUrls(candidate.card.id).any { downloadImage(it, raw) }
            if (downloaded && cropManifestCardRender(raw, target)) return@forEach
            target.delete()
        }
    }

    private data class RecipeCandidate(
        val card: DeckCard,
        var quantity: Int,
        val confidence: Int,
        var artworkScore: Int = 0
    ) {
        val combinedScore: Int get() = confidence + artworkScore
    }

    /**
     * Extract illustration crops from either the PC 10-column deck list or the
     * legacy phone left-panel layout. PC coordinates are normalized to the full
     * screenshot and include 40 Main Deck + up to 15 Extra Deck slots.
     */
    private fun extractDeckArtworkRows(source: Bitmap): List<List<ArtworkFingerprint>> {
        if (source.width < 500 || source.height < 350) return emptyList()
        if (!isDesktopDeckScreenshot(source)) return emptyList()
        return extractDesktopDeckArtworkRows(source)
    }

    private fun extractDesktopDeckArtworkRows(source: Bitmap): List<List<ArtworkFingerprint>> {
        val output = mutableListOf<List<ArtworkFingerprint>>()
        // Calibrated against the supplied 1378x1536 PC deck-list capture.
        // Ten columns: Main rows 1-4, Extra row 1; final Extra row has five cards.
        // Coordinates are normalized so the same layout scales with capture resolution.
        val tileW = source.width * 0.0670f
        val tileH = source.height * 0.0900f
        val xStart = 0.0320f
        val xPitch = 0.0788f
        val rowTops = listOf(0.1087f, 0.2070f, 0.3053f, 0.4029f, 0.6393f, 0.7330f)
        rowTops.forEachIndexed { rowIndex, normalizedTop ->
            val rowTiles = mutableListOf<ArtworkFingerprint>()
            val columns = if (rowIndex == 5) 5 else 10
            for (column in 0 until columns) {
                val left = (source.width * (xStart + column * xPitch)).toInt()
                val top = (source.height * normalizedTop).toInt()
                val right = (left + tileW).toInt().coerceAtMost(source.width)
                val bottom = (top + tileH).toInt().coerceAtMost(source.height)
                if (right - left < 40 || bottom - top < 50) continue
                // Ignore empty deck slots: real card tiles have substantial image/color variation.
                if (!hasCardTileTexture(source, left, top, right, bottom)) continue
                // Exclude frame, rarity ribbon, card title and effect text; retain artwork only.
                val artLeft = (left + tileW * 0.080f).toInt()
                val artTop = (top + tileH * 0.170f).toInt()
                val artRight = (left + tileW * 0.920f).toInt().coerceAtMost(source.width)
                val artBottom = (top + tileH * 0.710f).toInt().coerceAtMost(source.height)
                if (artRight <= artLeft || artBottom <= artTop) continue
                val crop = Bitmap.createBitmap(source, artLeft, artTop, artRight - artLeft, artBottom - artTop)
                try { rowTiles.add(fingerprint(crop)) } finally { crop.recycle() }
            }
            // Keep row boundaries intact. The last Extra Deck row has five slots in the reference layout.
            if (rowTiles.isNotEmpty()) output.add(rowTiles)
        }
        return output
    }

    private fun hasCardTileTexture(bitmap: Bitmap, left: Int, top: Int, right: Int, bottom: Int): Boolean {
        val sample = 8
        var sum = 0.0
        var sumSq = 0.0
        var count = 0
        var minL = 255
        var maxL = 0
        for (sy in 0 until sample) for (sx in 0 until sample) {
            val x = (left + (sx + 0.5f) / sample * (right - left)).toInt().coerceIn(left, right - 1)
            val y = (top + (sy + 0.5f) / sample * (bottom - top)).toInt().coerceIn(top, bottom - 1)
            val pixel = bitmap.getPixel(x, y)
            val l = (0.299 * android.graphics.Color.red(pixel) + 0.587 * android.graphics.Color.green(pixel) + 0.114 * android.graphics.Color.blue(pixel)).toInt()
            sum += l; sumSq += l.toDouble() * l; count++
            minL = minOf(minL, l); maxL = maxOf(maxL, l)
        }
        val mean = sum / count
        val variance = (sumSq / count - mean * mean).coerceAtLeast(0.0)
        return maxL - minL >= 38 && variance >= 150.0
    }

    /** Build a normalized 192-dimensional visual descriptor for each artwork crop. */
    private fun fingerprint(bitmap: Bitmap): ArtworkFingerprint =
        ArtworkFingerprint(ArtworkVectorizer.extract(bitmap))

    /** Cosine similarity between normalized artwork feature vectors. */
    private fun artworkSimilarity(a: ArtworkFingerprint, b: ArtworkFingerprint): Int {
        if (a.vector.size != b.vector.size || a.vector.isEmpty()) return 0
        var dot = 0f
        for (i in a.vector.indices) dot += a.vector[i] * b.vector[i]
        return ((dot.coerceIn(0f, 1f) * 100f).toInt()).coerceIn(0, 100)
    }

    private fun scoreCandidatesByArtwork(found: List<RecipeCandidate>, rows: List<List<ArtworkFingerprint>>) {
        if (rows.isEmpty()) return
        // If the same five-card row appears in multiple screenshots, retain it once.
        // Different rows from scrolled screenshots remain available for quantity counting.
        val uniqueRows = mutableListOf<List<ArtworkFingerprint>>()
        rows.forEach { row ->
            val duplicate = uniqueRows.any { prior ->
                row.size == prior.size && row.indices.map { artworkSimilarity(row[it], prior[it]) }.count { it >= 90 } >= minOf(4, row.size)
            }
            if (!duplicate) uniqueRows.add(row)
        }
        val directory = File(filesDir, "ygoprodeck_cropped_cache")
        found.forEach { candidate ->
            if (candidate.card.id <= 0) return@forEach
            val file = File(directory, "${candidate.card.id}.jpg")
            if (!file.exists() || file.length() <= 0L) return@forEach
            val vectorFile = File(filesDir, "artwork_vectors_v1/${candidate.card.id}.f32")
            val ref = loadOrCreateArtworkVector(file, vectorFile) ?: return@forEach
            val scores = uniqueRows.flatMap { row -> row.map { artworkSimilarity(ref, it) } }
            candidate.artworkScore = scores.maxOrNull() ?: 0
            // A repeated illustration in separate tiles represents repeated physical copies.
            val visualQuantity = scores.count { it >= 88 }.coerceAtMost(3)
            if (visualQuantity > candidate.quantity) candidate.quantity = visualQuantity
        }
    }

    private fun loadOrCreateArtworkVector(imageFile: File, vectorFile: File): ArtworkFingerprint? {
        if (vectorFile.exists() && vectorFile.length() == 192L * 4L) {
            return runCatching {
                val input = java.io.DataInputStream(vectorFile.inputStream())
                val values = FloatArray(192) { input.readFloat() }
                input.close()
                ArtworkFingerprint(values)
            }.getOrNull()
        }
        val bitmap = BitmapFactory.decodeFile(imageFile.absolutePath) ?: return null
        return try {
            val result = fingerprint(bitmap)
            vectorFile.parentFile?.mkdirs()
            java.io.DataOutputStream(vectorFile.outputStream()).use { out -> result.vector.forEach(out::writeFloat) }
            result
        } finally { bitmap.recycle() }
    }

    private fun normalizeOcrText(value: String): String = value.lowercase(Locale.ROOT)
        .replace(Regex("[^\\p{L}\\p{N}]"), "")

    private fun matchOcrLinesToCards(lines: List<String>): List<RecipeCandidate> {
        val catalogue = loadBundledKoreanCards()
        val candidates = linkedMapOf<String, RecipeCandidate>()
        val expandedLines = mutableListOf<String>()
        lines.forEachIndexed { index, line ->
            expandedLines.add(line)
            if (index + 1 < lines.size) expandedLines.add(line + " " + lines[index + 1])
        }
        for (rawLine in expandedLines) {
            val line = normalizeOcrText(rawLine)
            if (line.length < 3) continue
            val explicitQuantity = Regex("(?i)(?:[x×＊*]\\s*([1-3])|([1-3])\\s*(?:장|copies))")
                .find(rawLine)?.let { (it.groupValues[1].ifBlank { it.groupValues[2] }).toIntOrNull() } ?: 1
            var best: JSONObject? = null
            var bestScore = 0
            for (row in catalogue) {
                val ko = normalizeOcrText(row.optString("ko_name"))
                val en = normalizeOcrText(row.optString("en_name").ifBlank { row.optString("title") })
                if (ko.isBlank() && en.isBlank()) continue
                val score = when {
                    ko.length >= 3 && line.contains(ko) -> 100 + ko.length
                    en.length >= 4 && line.contains(en) -> 90 + en.length
                    else -> {
                        val shorter = listOf(ko, en).filter { it.length >= 5 }.minByOrNull { kotlin.math.abs(it.length - line.length) }
                        if (shorter != null && line.length >= 5 && kotlin.math.abs(shorter.length - line.length) <= 2 &&
                            editDistance(shorter, line) <= 2) 70 + shorter.length else 0
                    }
                }
                if (score > bestScore) { bestScore = score; best = row }
            }
            if (best != null && bestScore >= 70) {
                val password = best.optString("password")
                val id = password.toIntOrNull() ?: 0
                val type = classifyDetailedType(best, best.optString("types").ifBlank { "카드" })
                val name = best.optString("en_name").ifBlank { best.optString("title") }
                val imageUrl = best.optString("image_url")
                val effect = formattedKoreanEffect(best).ifBlank { cleanCardText(best.optString("ko_text")) }
                val card = DeckCard(id, name, imageUrl, type, sectionForType(type),
                    best.optString("ko_name"), effect, best.optString("level"))
                val key = password.ifBlank { normalizeOcrText(name) }
                val existing = candidates[key]
                if (existing == null) candidates[key] = RecipeCandidate(card, explicitQuantity, bestScore)
                else if (explicitQuantity > existing.quantity) existing.quantity = explicitQuantity
            }
        }
        return candidates.values.sortedByDescending { it.confidence }.take(80)
    }

    private fun editDistance(a: String, b: String): Int {
        if (kotlin.math.abs(a.length - b.length) > 2) return 3
        var previous = IntArray(b.length + 1) { it }
        for (i in a.indices) {
            val current = IntArray(b.length + 1)
            current[0] = i + 1
            for (j in b.indices) {
                current[j + 1] = minOf(current[j] + 1, previous[j + 1] + 1,
                    previous[j] + if (a[i] == b[j]) 0 else 1)
            }
            previous = current
        }
        return previous[b.length]
    }

    private fun showRecognizedDeckCandidates(found: List<RecipeCandidate>) {
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)) }
        val scroll = ScrollView(this)
        scroll.addView(container)
        val checks = mutableListOf<CheckBox>()
        found.forEach { candidate ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val check = CheckBox(this).apply {
                isChecked = true
                text = if (candidate.artworkScore > 0)
                    "${displayCardName(candidate.card)}  ×${candidate.quantity}  · 일러스트 유사도 ${candidate.artworkScore}%"
                else "${displayCardName(candidate.card)}  ×${candidate.quantity}  · OCR"
                textSize = 13f
            }
            checks.add(check)
            row.addView(check, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this).apply {
                text = KoreanCardNames.koreanType(candidate.card.type)
                textSize = 10f
                setTextColor(Color.DKGRAY)
            })
            container.addView(row)
        }
        AlertDialog.Builder(this)
            .setTitle("인식한 카드 ${found.size}종 확인")
            .setMessage("선택된 카드만 현재 덱에 추가합니다. 카드명 인식이 틀린 항목은 선택을 해제한 뒤 직접 검색해 주세요.")
            .setView(scroll)
            .setNegativeButton("취소", null)
            .setNeutralButton("모두 해제", null)
            .setPositiveButton("선택한 카드 추가") { _, _ ->
                found.forEachIndexed { index, candidate ->
                    if (checks[index].isChecked) {
                        repeat(candidate.quantity.coerceIn(1, 3)) { addCard(candidate.card) }
                    }
                }
                status.text = "사진에서 인식한 카드의 덱 추가가 완료되었습니다. 누락된 카드는 검색으로 보충해 주세요."
            }
            .show().apply {
                getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener { checks.forEach { it.isChecked = false } }
            }
    }

    private fun displayCardName(card: DeckCard): String =
        card.localizedName.ifBlank { KoreanCardNames.display(card.name) }

    private fun cleanCardText(value: String): String = value
        .replace(Regex("(?i)<br\\s*/?>"), "\n")
        .replace(Regex("(?i)</p>\\s*<p[^>]*>"), "\n")
        .replace(Regex("<[^>]*>"), "")
        .replace("&nbsp;", " ").replace("&amp;", "&")
        .replace("&lt;", "<").replace("&gt;", ">")
        .replace(Regex("[ \t]+\\n"), "\n")
        .trim()

    private fun findCardEffect(obj: JSONObject): String {
        val preferred = listOf("cardText", "card_text", "effect", "desc", "description", "text", "cardDesc")
        for (key in preferred) {
            val value = obj.opt(key)
            if (value is String && value.isNotBlank()) return cleanCardText(value)
        }
        return findText(obj, preferred)?.let(::cleanCardText).orEmpty()
    }

    private fun searchCards() {
        val q = search.text.toString().trim()
        if (q.isEmpty()) { status.text = "검색어를 입력하세요."; return }
        status.text = "한국어 카드 데이터베이스 검색 중…"
        results.removeAllViews()
        executor.execute {
            try {
                // Korean searches use the supplied offline catalogue; no API or
                // network download is needed for Korean card-name/effect lookup.
                val isKoreanQuery = q.any { it in '\uAC00'..'\uD7A3' }
                if (isKoreanQuery) {
                    val koreanResults = searchBundledKoreanFields(q, loadBundledKoreanCards())
                    runOnUiThread {
                        results.removeAllViews()
                        status.text = if (koreanResults.isEmpty()) "한국어 카드 검색 결과가 없습니다."
                            else "한국어 카드 데이터베이스 검색 결과 ${koreanResults.size}장"
                        koreanResults.forEach { addSearchRow(it) }
                    }
                    return@execute
                }
                val payload = loadGitHubCardDatabase()
                val rootJson = org.json.JSONTokener(payload).nextValue()
                val objects = mutableListOf<JSONObject>()
                collectCardObjects(rootJson, objects)
                // The Master Duel feed omits the primary type for many Spell/Trap cards.
                // Join the bundled, independently verified type catalogue by English name.
                val bundledRows = loadBundledKoreanCards()
                // Password is the stable card identity. English-name matching is only a
                // fallback for older feeds that omit the passcode.
                val bundledTypeIndexByPassword = bundledRows
                    .filter { it.optString("password").isNotBlank() }
                    .associateBy { it.optString("password") }
                val bundledTypeIndexByName = bundledRows.associateBy {
                    normalizeCardTypeKey(it.optString("en_name").ifBlank { it.optString("title") })
                }
                // English queries continue to use the existing Master Duel catalogue.
                val query = KoreanCardNames.englishFor(q).lowercase(java.util.Locale.ROOT)
                val found = mutableListOf<DeckCard>()
                val seen = mutableSetOf<String>()
                for (obj in objects) {
                    val names = cardNameCandidates(obj)
                    val matchedName = names.firstOrNull { it.lowercase(java.util.Locale.ROOT).contains(query) }
                    val archetypeMatch = cardArchetypeCandidates(obj).any { it.lowercase(java.util.Locale.ROOT).contains(query) }
                    if (matchedName == null && !archetypeMatch) continue
                    val actualName = matchedName ?: names.firstOrNull() ?: continue
                    val displayName = canonicalCardName(actualName.trim()) // Keep card identity, not archetype, for banlist matching.
                    val sourcePassword = findNumber(obj, listOf("password", "passcode", "cardPassword", "card_password"))
                    val typeRow = if (sourcePassword > 0) bundledTypeIndexByPassword[sourcePassword.toString()]
                        else bundledTypeIndexByName[normalizeCardTypeKey(actualName)]
                    typeRow?.let { row ->
                        obj.put("db_card_type", row.optString("db_card_type"))
                        obj.put("db_card_subtype", row.optString("db_card_subtype"))
                        obj.put("db_is_pendulum", row.optBoolean("db_is_pendulum"))
                        obj.put("db_is_non_effect", row.optBoolean("db_is_non_effect"))
                    }
                    val rawType = findCardType(obj) ?: inferTypeFromCardFields(obj) ?: "카드"
                    val type = classifyDetailedType(obj, rawType)
                    // Tokens are generated during play and must not appear in deck search.
                    if (type.contains("토큰") || rawType.contains("token", ignoreCase = true) || actualName.contains("token", ignoreCase = true)) continue
                    val id = findNumber(obj, listOf("password", "passcode", "id", "cid", "cardId", "card_id", "konami_id", "konamiId"))
                    val image = findImageUrl(obj) ?: if (id > 0) "https://images.ygoprodeck.com/images/cards/$id.jpg" else ""
                    val section = sectionForType(type)
                    val identity = if (id > 0) "id:$id" else "name:${actualName.trim().lowercase(java.util.Locale.ROOT)}"
                    val koreanRow = if (sourcePassword > 0) bundledTypeIndexByPassword[sourcePassword.toString()]
                        else bundledTypeIndexByName[normalizeCardTypeKey(actualName)]
                    val effect = koreanRow?.let { formattedKoreanEffect(it) }
                        ?.ifBlank { findCardEffect(obj) } ?: findCardEffect(obj)
                    val localized = KoreanCardNames.display(displayName).takeIf { it != displayName }.orEmpty()
                    if (seen.add(identity)) found.add(DeckCard(id, displayName, image, type, section, localized, effect, obj.optString("level")))
                    if (found.size >= 60) break
                }
                runOnUiThread {
                    results.removeAllViews()
                    if (found.isEmpty()) status.text = "GitHub 카드 데이터베이스에서 검색 결과를 찾지 못했습니다. 영문 카드명으로도 검색해 보세요."
                    else {
                        status.text = "GitHub 카드 데이터베이스 검색 결과 ${found.size}장"
                        found.forEach { addSearchRow(it) }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    val detail = generateSequence(e as Throwable?) { it.cause }
                        .mapNotNull { it.message?.takeIf(String::isNotBlank) }
                        .firstOrNull()
                    status.text = "GitHub 카드 데이터베이스 검색 실패 (${detail ?: e.javaClass.simpleName}). 인터넷 연결을 확인하세요."
                }
            }
        }
    }

    // Classify Spell/Trap subtypes from structured type fields, not effect text.
    // This avoids labeling a Normal Spell as Continuous merely because its effect
    // mentions a Continuous Spell, for example.
    private fun classifyDetailedType(obj: JSONObject, rawType: String): String {
        // Use the card's own type/subtype fields only. Never infer a subtype from
        // effect text or unrelated metadata (which caused false Continuous/Quick-Play labels).
        // Prefer the normalized card-type/subtype fields joined from the supplied
        // Yu-Gi-Oh database. This is authoritative for Spell/Trap classification.
        val dbBase = obj.optString("db_card_type")
        val dbSubtype = obj.optString("db_card_subtype")
        if (dbBase.equals("Spell", ignoreCase = true)) return when (dbSubtype) {
            "SpellQuickPlay" -> "Quick-Play Spell Card"
            "SpellContinuous" -> "Continuous Spell Card"
            "SpellEquip" -> "Equip Spell Card"
            "SpellField" -> "Field Spell Card"
            "SpellRitual" -> "Ritual Spell Card"
            else -> "Normal Spell Card"
        }
        if (dbBase.equals("Trap", ignoreCase = true)) return when (dbSubtype) {
            "TrapContinuous" -> "Continuous Trap Card"
            "TrapCounter" -> "Counter Trap Card"
            else -> "Normal Trap Card"
        }
        // The database subtype is authoritative for monsters too. The Master Duel
        // feed can omit or flatten the Fusion/Synchro/Xyz/Link token; relying only
        // on its display type would put those Extra Deck monsters in the Main Deck.
        if (dbBase.equals("Monster", ignoreCase = true)) {
            val pendulum = obj.optBoolean("db_is_pendulum") ||
                rawType.contains("pendulum", ignoreCase = true) || rawType.contains("펜듈럼")
            val baseMonster = when (dbSubtype) {
                "MonsterFusion" -> "Fusion Monster"
                "MonsterSynchro" -> "Synchro Monster"
                "MonsterXyz" -> "XYZ Monster"
                "MonsterLink" -> "Link Monster"
                "MonsterRitual" -> "Ritual Monster"
                "MonsterNormal" -> "Normal Monster"
                "MonsterEffect" -> "Effect Monster"
                else -> rawType
            }
            if (baseMonster.isNotBlank()) {
                // Effect Pendulum and Ritual Pendulum monsters keep their primary
                // monster classification; Pendulum is shown as a separate qualifier.
                if (pendulum && (baseMonster == "Effect Monster" || baseMonster == "Ritual Monster")) {
                    return "$baseMonster/Pendulum"
                }
                return if (pendulum && !baseMonster.contains("pendulum", ignoreCase = true))
                    "Pendulum $baseMonster" else baseMonster
            }
        }
        val locale = java.util.Locale.ROOT
        val explicitParts = mutableListOf<String>()
        val keys = listOf(
            "spell_type", "spellType", "trap_type", "trapType", "subtype", "sub_type",
            "card_subtype", "cardSubtype", "property", "spell_property", "trap_property"
        )
        for (key in keys) {
            val value = obj.opt(key)
            when (value) {
                is String -> if (value.isNotBlank()) explicitParts += value
                is org.json.JSONArray -> for (i in 0 until value.length()) {
                    val item = value.opt(i)
                    if (item is String && item.isNotBlank()) explicitParts += item
                }
            }
        }
        val base = rawType.lowercase(locale)
        val subtype = explicitParts.joinToString(" ").lowercase(locale)
        val evidence = "$base $subtype"
        val isSpell = base.contains("spell") || base == "spell" || base.contains("마법")
        val isTrap = base.contains("trap") || base == "trap" || base.contains("함정")
        if (isSpell) return when {
            evidence.contains("quick-play") || evidence.contains("quick play") || evidence.contains("속공") -> "Quick-Play Spell Card"
            evidence.contains("continuous") || evidence.contains("지속") -> "Continuous Spell Card"
            evidence.contains("equip") || evidence.contains("장착") -> "Equip Spell Card"
            evidence.contains("field") || evidence.contains("필드") -> "Field Spell Card"
            evidence.contains("ritual") || evidence.contains("의식") -> "Ritual Spell Card"
            else -> "Normal Spell Card"
        }
        if (isTrap) return when {
            evidence.contains("counter") || evidence.contains("카운터") -> "Counter Trap Card"
            evidence.contains("continuous") || evidence.contains("지속") -> "Continuous Trap Card"
            else -> "Normal Trap Card"
        }
        return rawType
    }

    private fun cardNameCandidates(obj: JSONObject): List<String> {
        val out = linkedSetOf<String>()
        fun walk(value: Any?, parentKey: String = "") {
            when (value) {
                is JSONObject -> {
                    val keys = value.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        val child = value.opt(key)
                        val lower = key.lowercase()
                        if (lower in listOf("name", "cardname", "card_name", "title", "koreanname", "korean_name", "name_ko", "name_en", "englishname", "english_name", "en", "ko", "ja", "jp")) {
                            if (child is String && child.isNotBlank()) out.add(child)
                            else if (child is JSONObject || child is org.json.JSONArray) walk(child, lower)
                        } else if (child is JSONObject || child is org.json.JSONArray) walk(child, lower)
                    }
                }
                is org.json.JSONArray -> for (i in 0 until value.length()) walk(value.opt(i), parentKey)
            }
        }
        walk(obj)
        // Keep only plausible names, avoiding the entire effect text as a candidate.
        return out.filter { it.length in 2..120 && !it.contains("\n") }
    }

    private fun cardArchetypeCandidates(obj: JSONObject): List<String> {
        val out = linkedSetOf<String>()
        val keys = setOf("archetype", "set_name", "setname", "theme", "card_archetype")
        fun walk(value: Any?) {
            when (value) {
                is JSONObject -> {
                    val iterator = value.keys()
                    while (iterator.hasNext()) {
                        val key = iterator.next()
                        val child = value.opt(key)
                        if (key.lowercase() in keys) {
                            when (child) {
                                is String -> if (child.isNotBlank()) out.add(child)
                                is org.json.JSONArray -> for (i in 0 until child.length()) {
                                    val item = child.opt(i)
                                    if (item is String && item.isNotBlank()) out.add(item)
                                }
                            }
                        } else if (child is JSONObject || child is org.json.JSONArray) walk(child)
                    }
                }
                is org.json.JSONArray -> for (i in 0 until value.length()) walk(value.opt(i))
            }
        }
        walk(obj)
        return out.toList()
    }

    private fun findImageUrl(obj: JSONObject): String? {
        val preferred = listOf("image_url", "imageUrl", "image", "card_image", "cardImage", "art_url", "artUrl", "picture", "art")
        fun walk(value: Any?): String? {
            when (value) {
                is JSONObject -> {
                    for (key in preferred) {
                        val child = value.opt(key)
                        if (child is String && child.startsWith("http", true) &&
                            (child.contains(".jpg", true) || child.contains(".png", true) || child.contains(".webp", true))) return child
                        if (child is JSONObject || child is org.json.JSONArray) walk(child)?.let { return it }
                    }
                    val keys = value.keys()
                    while (keys.hasNext()) {
                        val child = value.opt(keys.next())
                        if (child is JSONObject || child is org.json.JSONArray) walk(child)?.let { return it }
                    }
                }
                is org.json.JSONArray -> for (i in 0 until value.length()) walk(value.opt(i))?.let { return it }
            }
            return null
        }
        return walk(obj)
    }


    private fun deckCardForDatabaseId(databaseId: Int): DeckCard? {
        val obj = loadBundledKoreanCards().firstOrNull { it.optInt("db_card_id") == databaseId } ?: return null
        val koreanName = obj.optString("ko_name").trim()
        val englishName = obj.optString("en_name").trim().ifBlank { obj.optString("title").trim() }
        if (englishName.isBlank() || koreanName.isBlank()) return null
        val rawType = findCardType(obj) ?: inferTypeFromCardFields(obj) ?: "카드"
        val type = classifyDetailedType(obj, rawType)
        if (type.contains("토큰") || koreanName.contains("토큰")) return null
        val cardPassword = findNumber(obj, listOf("password", "passcode", "id", "cid", "cardId", "card_id"))
        if (cardPassword <= 0) return null
        val image = findImageUrl(obj) ?: ""
        val effect = formattedKoreanEffect(obj).ifBlank { cleanCardText(obj.optString("ko_text")) }
        return DeckCard(cardPassword, canonicalCardName(englishName), image, type, sectionForType(type), koreanName, effect, obj.optString("level"))
    }

    private fun loadBundledKoreanCards(): List<JSONObject> {
        bundledKoreanCardsCache?.let { return it }
        synchronized(this) {
            bundledKoreanCardsCache?.let { return it }
            val payload = assets.open("korean_master_duel_cards.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            val array = org.json.JSONArray(payload)
            val parsed = List(array.length()) { index -> array.getJSONObject(index) }
            bundledKoreanCardsCache = parsed
            return parsed
        }
    }

    private fun normalizeCardTypeKey(value: String): String =
        value.lowercase(java.util.Locale.ROOT).replace(Regex("[^a-z0-9가-힣]"), "")

    private fun formattedKoreanEffect(obj: JSONObject): String {
        val monster = cleanCardText(obj.optString("ko_monster_effect"))
            .ifBlank { cleanCardText(obj.optString("ko_text")) }
        val pendulum = cleanCardText(obj.optString("ko_pendulum_effect"))
        if (pendulum.isBlank()) return monster
        return buildString {
            append("【펜듈럼 효과】\n")
            append(pendulum)
            append("\n\n【몬스터 효과】\n")
            append(monster.ifBlank { "몬스터 효과가 없습니다." })
        }
    }

    private fun searchBundledKoreanFields(query: String, masterCards: List<JSONObject>): List<DeckCard> {
        val q = query.trim().lowercase(java.util.Locale.ROOT)
        val ranked = mutableListOf<Pair<Int, DeckCard>>()
        val seen = mutableSetOf<String>()
        for (obj in masterCards) {
            val koreanName = obj.optString("ko_name").trim()
            val koreanEffect = obj.optString("ko_text").trim()
            if (koreanName.isBlank()) continue
            val nameMatch = koreanName.lowercase(java.util.Locale.ROOT).contains(q)
            val effectMatch = koreanEffect.lowercase(java.util.Locale.ROOT).contains(q)
            if (!nameMatch && !effectMatch) continue

            val englishName = obj.optString("en_name").trim()
                .ifBlank { obj.optString("title").trim() }
                .ifBlank { cardNameCandidates(obj).firstOrNull().orEmpty() }
            if (englishName.isBlank()) continue
            val rawType = findCardType(obj) ?: inferTypeFromCardFields(obj) ?: "카드"
            val type = classifyDetailedType(obj, rawType)
            if (type.contains("토큰") || englishName.contains("token", ignoreCase = true) || koreanName.contains("토큰")) continue
            val id = findNumber(obj, listOf("password", "passcode", "id", "cid", "cardId", "card_id", "konami_id", "konamiId"))
            val image = findImageUrl(obj) ?: if (id > 0) "https://images.ygoprodeck.com/images/cards/$id.jpg" else ""
            val displayName = canonicalCardName(englishName)
            val key = if (id > 0) "id:$id" else "name:${englishName.lowercase(java.util.Locale.ROOT)}"
            if (!seen.add(key)) continue
            val effect = formattedKoreanEffect(obj).ifBlank { cleanCardText(koreanEffect) }
            val card = DeckCard(id, displayName, image, type, sectionForType(type), koreanName, effect, obj.optString("level"))
            // Name matches first; effect-text matches provide archetype/theme discovery.
            ranked += (if (nameMatch) 0 else 1) to card
        }
        return ranked.sortedBy { it.first }.take(60).map { it.second }
    }

    private fun searchKoreanCardDatabase(query: String, masterCards: List<JSONObject>): List<DeckCard> {
        val address = "https://api.yugiohcard.kr/card/" + URLEncoder.encode(query, "UTF-8")
        var connection: HttpURLConnection? = null
        try {
            connection = (URL(address).openConnection(Proxy.NO_PROXY) as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 12000
                readTimeout = 15000
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "MDTracker-Android")
                instanceFollowRedirects = true
                useCaches = false
            }
            if (connection.responseCode !in 200..299) return emptyList()
            val payload = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (payload.isBlank()) return emptyList()
            val root = org.json.JSONTokener(payload).nextValue()
            val objects = mutableListOf<JSONObject>()
            collectCardObjects(root, objects)
            if (root is JSONObject && root.optString("cardName").isNotBlank() && objects.none { it === root }) objects.add(0, root)
            val out = mutableListOf<DeckCard>()
            val seen = mutableSetOf<String>()
            for (obj in objects) {
                val koreanName = obj.optString("cardName").trim()
                    .ifBlank { obj.optString("koreanName").trim() }
                    .ifBlank { obj.optString("name_ko").trim() }
                if (koreanName.isBlank() || koreanName.contains("찾을 수 없") || koreanName.contains("오류")) continue
                val rawType = findCardType(obj)
                    ?: koreanTypeFromOther(obj.optString("cardOther").ifBlank { obj.optString("card_other") })
                val type = classifyDetailedType(obj, rawType.ifBlank { "카드" })
                if (type.contains("토큰") || koreanName.contains("토큰")) continue
                val password = findNumber(obj, listOf("password", "passcode", "cardPassword", "card_password"))
                if (password <= 0) continue
                // Join Korean text to the Master Duel row by card password. Never
                // treat the password as an image ID: the image may use another ID
                // or a Master Duel-specific artwork URL.
                val master = masterCards.firstOrNull { candidate ->
                    findNumber(candidate, listOf("password", "passcode", "cardPassword", "card_password", "id")) == password
                } ?: continue
                val mdNames = cardNameCandidates(master)
                val englishName = mdNames.firstOrNull { it.any { ch -> ch in 'A'..'Z' || ch in 'a'..'z' } }
                    ?: KoreanCardNames.englishFor(koreanName)
                val mdId = findNumber(master, listOf("id", "cid", "cardId", "card_id", "konami_id", "konamiId", "password", "passcode"))
                val image = findImageUrl(master).orEmpty()
                val masterType = findCardType(master) ?: inferTypeFromCardFields(master)
                val finalType = if (type == "카드" && !masterType.isNullOrBlank()) classifyDetailedType(master, masterType) else type
                val key = "password:$password"
                val effect = findCardEffect(obj).ifBlank { findCardEffect(master) }
                if (seen.add(key)) out.add(DeckCard(mdId, englishName, image, finalType, sectionForType(finalType), koreanName, effect, master.optString("level")))
                if (out.size >= 60) break
            }
            return out
        } catch (_: Exception) {
            return emptyList()
        } finally {
            connection?.disconnect()
        }
    }

    private fun loadGitHubCardDatabase(): String {
        val cache = java.io.File(filesDir, "master-duel-raw.json")
        if (cache.exists() && cache.length() > 1000L) {
            val cached = runCatching { cache.readText(Charsets.UTF_8) }.getOrNull()
            if (!cached.isNullOrBlank() && runCatching { org.json.JSONTokener(cached).nextValue() }.isSuccess) return cached
            cache.delete()
        }
        val candidates = listOf(
            "https://dawnbrandbots.github.io/yaml-yugi/master-duel-raw.json",
            "https://raw.githubusercontent.com/DawnbrandBots/yaml-yugi/aggregate/master-duel-raw.json"
        )
        var lastError: Exception? = null
        for (address in candidates) {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(address).openConnection(Proxy.NO_PROXY) as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 20000
                    readTimeout = 30000
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("User-Agent", "MDTracker-Android")
                    instanceFollowRedirects = true
                    useCaches = false
                }
                if (connection.responseCode in 200..299) {
                    val text = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    if (text.length < 1000) throw java.io.IOException("GitHub 데이터가 비어 있거나 너무 작습니다.")
                    cache.writeText(text, Charsets.UTF_8)
                    return text
                } else lastError = java.io.IOException("HTTP ${connection.responseCode}")
            } catch (e: Exception) { lastError = e }
            finally { connection?.disconnect() }
        }
        throw lastError ?: java.io.IOException("GitHub 데이터 다운로드 실패")
    }

    private fun collectCardObjects(value: Any?, output: MutableList<JSONObject>) {
        when (value) {
            is JSONObject -> {
                if (findText(value, listOf("name", "cardName", "title", "koreanName", "name_ko")) != null) output.add(value)
                val keys = value.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val child = value.opt(key)
                    if (child is JSONObject || child is org.json.JSONArray) collectCardObjects(child, output)
                }
            }
            is org.json.JSONArray -> for (i in 0 until value.length()) collectCardObjects(value.opt(i), output)
        }
    }

    private fun findText(obj: JSONObject, keys: List<String>): String? {
        for (key in keys) {
            val value = obj.opt(key)
            if (value is String && value.isNotBlank()) return value
            if (value is JSONObject) {
                val nested = value.optString("ko").takeIf { it.isNotBlank() }
                    ?: value.optString("en").takeIf { it.isNotBlank() }
                    ?: value.optString("name").takeIf { it.isNotBlank() }
                if (nested != null) return nested
            }
        }
        return null
    }


    // YAML Yugi uses several type fields depending on the card/schema version.
    // Search nested objects too; looking only for a top-level "type" silently
    // classified every card as the generic fallback.
    private fun findCardType(obj: JSONObject): String? {
        val preferredKeys = listOf(
            "monster_type_line", "monsterTypeLine", "type_line", "typeLine",
            "card_type", "cardType", "card_type_name", "cardTypeName",
            "frame_type", "frameType", "frame", "monster_type", "monsterType",
            "monster_types", "monsterTypes", "card_types", "cardTypes", "types",
            "cardOther", "kind", "type", "subtype", "sub_type", "category", "classification"
        )
        for (key in preferredKeys) {
            val value = obj.opt(key)
            val text = typeValueToText(value)
            if (!text.isNullOrBlank() && looksLikeCardType(text)) return text
        }
        val keys = obj.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val child = obj.opt(key)
            if (child is JSONObject) {
                findCardType(child)?.let { return it }
            } else if (child is org.json.JSONArray) {
                // Some card datasets store type lines as arrays of strings rather than objects.
                val strings = (0 until child.length()).mapNotNull { i ->
                    val item = child.opt(i)
                    when (item) {
                        is String -> item.takeIf { it.isNotBlank() }
                        is JSONObject -> typeValueToText(item)
                        else -> null
                    }
                }.joinToString(" / ")
                if (strings.isNotBlank() && looksLikeCardType(strings)) return strings
                for (i in 0 until child.length()) {
                    val item = child.opt(i)
                    if (item is JSONObject) findCardType(item)?.let { return it }
                }
            }
        }
        return null
    }


    // Last-resort schema-aware inference for datasets where the primary type is split
    // across fields (for example frame + monster types) instead of a single type string.
    private fun inferTypeFromCardFields(obj: JSONObject): String? {
        val all = obj.toString().lowercase()
        val keys = obj.keys().asSequence().map { it.lowercase() }.toSet()
        val explicit = listOf("frame_type", "frame", "frameType", "card_type", "cardType", "type_line", "typeLine")
            .firstNotNullOfOrNull { key -> obj.optString(key).takeIf { it.isNotBlank() && it != "null" } }
        if (explicit != null) return explicit
        // Only use structural clues, not arbitrary occurrences in the card name/text.
        fun has(vararg terms: String): Boolean = terms.any { term -> keys.any { it.contains(term) } }
        if (has("spell")) return when {
            all.contains("quick-play") -> "Quick-Play Spell Card"
            all.contains("continuous") -> "Continuous Spell Card"
            all.contains("equip") -> "Equip Spell Card"
            all.contains("field") -> "Field Spell Card"
            all.contains("ritual") -> "Ritual Spell Card"
            else -> "Spell Card"
        }
        if (has("trap")) return if (all.contains("counter")) "Counter Trap Card" else "Trap Card"
        if (has("fusion")) return if (all.contains("pendulum")) "Pendulum Fusion Monster" else "Fusion Monster"
        if (has("synchro")) return if (all.contains("pendulum")) "Pendulum Synchro Monster" else "Synchro Monster"
        if (has("xyz")) return if (all.contains("pendulum")) "Pendulum XYZ Monster" else "XYZ Monster"
        if (has("link")) return "Link Monster"
        if (has("ritual")) return "Ritual Monster"
        if (has("pendulum")) return if (all.contains("normal")) "Pendulum Normal Monster" else "Pendulum Effect Monster"
        if (has("monster", "attribute", "level", "atk", "def")) return if (all.contains("normal")) "Normal Monster" else "Effect Monster"
        return null
    }

    private fun typeValueToText(value: Any?): String? {
        return when (value) {
            is String -> value.takeIf { it.isNotBlank() }
            is Number -> null
            is org.json.JSONArray -> (0 until value.length()).mapNotNull { i ->
                val item = value.opt(i)
                when (item) {
                    is String -> item
                    is JSONObject -> listOf("name", "en", "type", "value").firstNotNullOfOrNull { k ->
                        item.optString(k).takeIf { it.isNotBlank() }
                    }
                    else -> null
                }
            }.joinToString(" / ").takeIf { it.isNotBlank() }
            is JSONObject -> listOf("en", "name", "type", "value", "label").firstNotNullOfOrNull { k ->
                value.optString(k).takeIf { it.isNotBlank() }
            }
            else -> null
        }
    }

    private fun looksLikeCardType(value: String): Boolean {
        val t = value.lowercase()
        return listOf("monster", "spell", "trap", "normal", "effect", "fusion", "synchro", "xyz", "link", "ritual", "pendulum", "tuner", "token", "quick-play", "continuous", "equip", "field", "counter", "일반", "효과", "토큰", "마법", "함정", "몬스터", "펜듈럼", "융합", "싱크로", "엑시즈", "링크", "의식", "속공", "지속", "장착", "필드", "카운터").any { t.contains(it) }
    }

    private fun findNumber(obj: JSONObject, keys: List<String>): Int {
        for (key in keys) {
            val value = obj.opt(key)
            if (value is Number && value.toInt() > 0) return value.toInt()
            if (value is String) value.toIntOrNull()?.let { if (it > 0) return it }
        }
        return 0
    }

    private fun koreanTypeFromOther(other: String): String {
        val raw = other.replace("[", "").replace("]", "").trim()
        if (raw.isBlank()) return "카드"
        val terms = raw.split("/").map { it.trim() }.filter { it.isNotBlank() }
        val out = mutableListOf<String>()
        val joined = terms.joinToString(" ")
        if (joined.contains("마법")) return when {
            joined.contains("속공") -> "속공 마법"
            joined.contains("지속") -> "지속 마법"
            joined.contains("장착") -> "장착 마법"
            joined.contains("필드") -> "필드 마법"
            joined.contains("의식") -> "의식 마법"
            else -> "일반 마법"
        }
        if (joined.contains("함정")) return when {
            joined.contains("카운터") -> "카운터 함정"
            joined.contains("지속") -> "지속 함정"
            else -> "일반 함정"
        }
        val primary = when {
            joined.contains("링크") -> "링크 몬스터"
            joined.contains("엑시즈") -> "엑시즈 몬스터"
            joined.contains("싱크로") -> "싱크로 몬스터"
            joined.contains("융합") -> "융합 몬스터"
            joined.contains("의식") -> "의식 몬스터"
            joined.contains("일반") -> "일반 몬스터"
            joined.contains("효과") -> "효과 몬스터"
            else -> "몬스터"
        }
        out += primary
        if (joined.contains("펜듈럼")) out += "펜듈럼"
        if (joined.contains("튜너")) out += "튜너"
        if (joined.contains("리버스") || joined.contains("반전")) out += "리버스"
        if (joined.contains("듀얼")) out += "듀얼"
        if (joined.contains("스피릿")) out += "스피릿"
        if (joined.contains("유니온")) out += "유니온"
        if (joined.contains("툰")) out += "툰"
        return out.distinct().joinToString("/")
    }

    private fun addSearchRow(card: DeckCard) {
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(4),dp(4),dp(4),dp(4)); setBackgroundColor(Color.WHITE) }
        val image=ImageView(this).apply { scaleType=ImageView.ScaleType.FIT_CENTER }
        row.addView(image,LinearLayout.LayoutParams(dp(54),dp(76)))
        val limit = cardLimit(card)
        val limitLabel = when (limit) { 0 -> "금지"; 1 -> "제한 · 최대 1장"; 2 -> "준제한 · 최대 2장"; else -> "무제한 · 최대 3장" }
        val textColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), 0, dp(4), 0) }
        val name = TextView(this).apply {
            text = "${displayCardName(card)}\n${KoreanCardNames.koreanType(card.type)} · ${limitLabel}"
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setTextColor(if (limit == 0) Color.RED else Color.DKGRAY)
        }
        textColumn.addView(name)
        if (card.effect.isNotBlank()) {
            textColumn.addView(TextView(this).apply {
                text = card.effect
                textSize = 10f
                setTextColor(Color.DKGRAY)
                maxLines = 4
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
        }
        textColumn.setOnClickListener { showCardDetails(card) }
        row.setOnClickListener { showCardDetails(card) }
        row.addView(textColumn, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply { text="+"; isEnabled = limit > 0; setOnClickListener { addCard(card) } },LinearLayout.LayoutParams(dp(52),dp(48)))
        results.addView(row,LinearLayout.LayoutParams(-1,-2))
        loadImage(card.image,image,card.id)
    }
    private fun loadImage(url: String, target: ImageView, cardId: Int = 0) {
        val urls = linkedSetOf<String>()
        if (url.isNotBlank()) urls.add(url)
        if (cardId > 0) {
            urls.add("https://images.ygoprodeck.com/images/cards/${cardId}.jpg")
            urls.add("https://images.ygoprodeck.com/images/cards_small/${cardId}.jpg")
        }
        if (urls.isEmpty()) return
        val key = urls.first()
        imageCache.get(key)?.let { target.setImageBitmap(it); return }
        target.tag = key
        executor.execute {
            var bitmap: android.graphics.Bitmap? = null
            for (candidate in urls) {
                var connection: HttpURLConnection? = null
                try {
                    connection = URL(candidate).openConnection() as HttpURLConnection
                    connection.connectTimeout = 9000
                    connection.readTimeout = 9000
                    connection.setRequestProperty("User-Agent", "MDTracker-Android")
                    connection.instanceFollowRedirects = true
                    connection.connect()
                    if (connection.responseCode in 200..299) {
                        bitmap = connection.inputStream.use { BitmapFactory.decodeStream(it) }
                        if (bitmap != null) break
                    }
                } catch (_: Exception) {
                } finally { connection?.disconnect() }
            }
            if (bitmap != null) {
                imageCache.put(key, bitmap!!)
                val result = bitmap
                runOnUiThread { if (target.tag == key) target.setImageBitmap(result) }
            }
        }
    }
    private fun sectionForType(type: String): String {
        val t = type.lowercase(java.util.Locale.ROOT)
        // The bundled catalogue uses type lines such as "Warrior / Fusion / Effect",
        // not only the phrase "Fusion Monster". Match the actual type token so every
        // Fusion, Synchro, Xyz and Link monster (including Pendulum variants) goes EXTRA.
        val extraMonsterToken = Regex("(^|[^a-z])(fusion|synchro|xyz|link)([^a-z]|$)")
        return if (extraMonsterToken.containsMatchIn(t) ||
            listOf("융합", "싱크로", "엑시즈", "링크").any { t.contains(it) }) "EXTRA" else "MAIN"
    }

    // Master Duel Forbidden & Limited List effective 2026-10-06.
    // Canonical names are English database names. Copy limit: Forbidden=0, Limited=1,
    // Semi-Limited=2, Unlimited=3. This is the Master Duel list, not OCG/TCG.
    private val forbiddenNames = setOf(
        "abyss dweller", "agido the ancient sentinel", "amazoness archer", "anti-spell fragrance",
        "apollousa, bow of the goddess", "appointer of the red lotus", "archlord kristya",
        "artifact mjollnir", "artifact scythe", "barrier statue of the drought", "barrier statue of the stormwinds",
        "beatrice, lady of the eternal", "blackwing - gofu the vague shadow", "branded expulsion",
        "butterfly dagger - elma", "called by the grave", "cannon soldier", "cannon soldier mk-2",
        "card of demise", "card of safe return", "catapult turtle", "chaos ruler, the chaotic magical dragon",
        "cold wave", "confiscation", "crystron halqifibrax", "cyber-stein", "dandylion", "delinquent duo",
        "dimension fusion", "dimension shifter", "divine sword - phoenix blade", "djinn releaser of rituals",
        "elder entity norden", "evilswarm ouroboros", "fiber jar", "fishborg blaster", "fossil dyna pachycephalo",
        "giant trunade", "gimmick puppet nightmare", "graceful charity", "grinder golem", "guardragon agarpain",
        "guardragon elpy", "harpie's feather storm", "hot red dragon archfiend king calamity",
        "ido the supreme magical force", "imperial order", "jowgen the spiritualist", "kaiser colosseum",
        "kelbek the ancient vanguard", "knightmare corruptor iblee", "last turn", "last will", "lavalval chain",
        "level eater", "life equalizer", "linkross", "lyrilusc - independent nightingale", "magical explosion",
        "magical scientist", "maliss q red ransom", "mass driver", "mind master", "mirage of nightmare",
        "mystic mine", "naturia rosewhip", "number 16: shock master", "number 41: bagooska the terribly tired tapir",
        "number 67: pair-a-dice smasher", "number 86: heroic champion - rhongomyniad",
        "number 89: diablosis the mind hacker", "number 95: galaxy-eyes dark matter dragon", "number s0: utopic zexal",
        "obedience schooled", "outer entity azathot", "psy-framelord omega", "painful choice",
        "performapal five-rainbow magician", "phantasmal lord ultimitl bishbaalkin", "phoenixian cluster amaryllis",
        "pot of greed", "pot of prosperity", "premature burial", "primeval planet perlereino",
        "return from the different dimension", "royal oppression", "ryzeal cross", "secret village of the spellcasters",
        "self-destruct button", "set rotation", "sixth sense", "smoke grenade of the thief", "soul charge",
        "substitoad", "summon limit", "superheavy samurai soulbreaker armor", "synchro overtake", "tearlaments merrli",
        "tempest magician", "terraforming", "the forceful sentry", "the tyrant neptune", "toadally awesome",
        "toon cannon soldier", "topologic gumblar dragon", "trap dustshoot", "true king of all calamities",
        "ultimate offering", "union carrier", "vanity's emptiness", "wind-up hunter"
    )
    private val limitedNames = setOf(
        "allure of darkness", "amano-iwato", "blaze fenix, the burning bombardment bird", "bonfire", "branded fusion",
        "bystial magnamhut", "card destruction", "crossout designator", "cupsy☆yummy", "dracotail lukias",
        "exodia the forbidden one", "ext ryzeal", "fairy tail - snow", "floowandereeze and the magnificent map",
        "foolish burial", "foolish burial goods", "gold sarcophagus", "gozen match", "harpie's feather duster",
        "heavy storm", "herald of orange light", "herald of the arc light", "inspector boarder", "instant fusion",
        "keldo the sacred protector", "kewl tune cue", "kewl tune rotary", "left arm of the forbidden one",
        "left leg of the forbidden one", "maliss p chessy cat", "maliss p dormouse", "maliss p white rabbit",
        "maliss in underground", "maxx \"c\"", "mitsurugi prayers", "mitsurugi no kensei", "monster reborn", "mudora the sword oracle",
        "one day of peace", "one for one", "psy-framegear gamma", "pot of duality", "pot of extravagance",
        "predaplant verte anaconda", "pressured planet wraitsoth", "radiant typhoon vision", "rahu dracotail",
        "reinforcement of the army", "right arm of the forbidden one", "right leg of the forbidden one",
        "rivalry of warlords", "runick destruction", "runick fountain", "sangen kaimen", "sangen summoning",
        "skill drain", "sky striker mecha - hornet drones", "snake-eye ash", "solemn judgment", "solemn strike",
        "solemn warning", "stake your soul!", "superheavy samurai soulpiercer", "sword ryzeal", "synchro zone",
        "tearlaments kashtira", "tearlaments kitkallos", "tearlaments sulliek", "tenpai dragon chundra",
        "that grass looks greener", "there can be only one", "wanted: seeker of sinful spoils", "zoodiac broadbull"
    )
    private val semiLimitedNames = setOf(
        "ame no habakiri no mitsurugi", "d.d. dynamite", "dracotail mululu", "droll & lock bird",
        "fiendsmith engraver", "k9-66a jokul", "kashtira unicorn", "ketu dracotail", "kewl tune mix",
        "kewl tune reco", "kewl tune synchro", "marshmao☆yummy", "necroface", "radiant typhoon chant",
        "radiant typhoon eldam", "red reboot", "runick freezing curses", "runick slumber", "runick tip",
        "super polymerization", "tearlaments scheiren", "the fallen & the virtuous", "treasures of the kings",
        "vanquish soul jiaolong", "vanquish soul razen", "zoodiac ratpier"
    )
    private fun canonicalCardName(value: String): String {
        val trimmed = value.trim()
        // Search databases may return the localized Korean alias as the card's canonical name.
        // Convert known aliases back to the English Master Duel banlist name before comparing.
        return when (trimmed.replace(Regex("\\s+"), "").lowercase(java.util.Locale.ROOT)) {
            "아메노하바키리노미츠루기" -> "Ame no Habakiri no Mitsurugi"
            "미츠루기권청" -> "Mitsurugi no Kensei"
            else -> trimmed
        }
    }

    private fun normalizedCardName(value: String): String = canonicalCardName(value)
        .replace('＜', '<').replace('＞', '>').replace('＆', '&').replace('★', '☆')
        .replace('’', '\'').replace('‘', '\'').replace('–', '-').replace('—', '-')
        .lowercase(java.util.Locale.ROOT)
        .replace("maliss <p>", "maliss p").replace("maliss <q>", "maliss q")
        // Ignore punctuation/spacing differences between card database and banlist names.
        .replace(Regex("[^a-z0-9가-힣]+"), "")

    private fun cardLimit(card: DeckCard): Int {
        val n = normalizedCardName(card.name)
        // Compare normalized keys on both sides. This avoids silently treating a listed
        // card as Unlimited because one source uses different punctuation or spacing.
        return when {
            forbiddenNames.any { normalizedCardName(it) == n } -> 0
            limitedNames.any { normalizedCardName(it) == n } -> 1
            semiLimitedNames.any { normalizedCardName(it) == n } -> 2
            else -> 3
        }
    }

    private fun addCard(card:DeckCard) {
        // Deck placement is determined by the card's type, not by a user-selected tab.
        val target = sectionForType(card.type)
        val normalizedType = card.type.lowercase()
        if (normalizedType.contains("펜듈럼") || normalizedType.contains("pendulum")) {
            val extraType = sectionForType(normalizedType) == "EXTRA"
            // Type lines commonly say "Pendulum / Effect" or "Pendulum / Normal";
            // requiring the phrase "Effect Monster" rejected valid Main-Deck Pendulums.
            // Main-Deck Pendulum monsters include Normal, Effect and Ritual.
            // Ritual Pendulum monsters were previously rejected because this guard
            // only accepted Normal/Effect, despite their type being classified correctly.
            val normalOrEffect = normalizedType.contains("일반 몬스터") ||
                normalizedType.contains("효과 몬스터") || normalizedType.contains("의식 몬스터") ||
                Regex("(^|[^a-z])(normal|effect|ritual)([^a-z]|$)").containsMatchIn(normalizedType) ||
                normalizedType.contains("normal monster") || normalizedType.contains("effect monster") ||
                normalizedType.contains("ritual monster")
            if (!extraType && !normalOrEffect) {
                toast("펜듈럼 몬스터 종류를 판별할 수 없어 추가하지 않았습니다.")
                return
            }
        }
        val allowedCopies = cardLimit(card)
        if (allowedCopies == 0) { toast("2026년 10월 금제에서 금지된 카드입니다."); return }
        val total=cards.count{it.section==target}; if(target=="MAIN"&&total>=60){toast("메인 덱은 최대 60장입니다.");return}; if(target=="EXTRA"&&total>=15){toast("엑스트라 덱은 최대 15장입니다.");return}
        // Some database rows do not expose a usable passcode, so several unrelated cards
        // can have id == 0. Never use that sentinel as a shared card identity. Yu-Gi-Oh!
        // copy limits apply by card name (including alternate printings), not database row ID.
        val normalizedName = normalizedCardName(card.name)
        val copies = cards.count {
            normalizedCardName(it.name) == normalizedName
        }
        if(copies>=allowedCopies){toast("2026년 10월 금제에 따라 이 카드는 최대 ${allowedCopies}장까지 넣을 수 있습니다.");return}
        cards.add(card.copy(section=target)); renderDeck()
    }
    private fun renderDeck() {
        if (!::deckList.isInitialized) return
        deckList.removeAllViews()
        val main = cards.filter { it.section == "MAIN" }
        val extra = cards.filter { it.section == "EXTRA" }
        deckList.addView(label("메인 덱 ${main.size}/60 ${if (main.size < 40) "(최소 40장 필요)" else ""}", 13f))
        groupedCards(sortDeckCards(main, false)).forEach { (card, count) -> addDeckRow(card, count, "MAIN") }
        deckList.addView(label("엑스트라 덱 ${extra.size}/15", 13f))
        groupedCards(sortDeckCards(extra, true)).forEach { (card, count) -> addDeckRow(card, count, "EXTRA") }
        if (cards.isEmpty()) deckList.addView(label("아직 추가한 카드가 없습니다.", 12f))
    }

    // Match Master Duel's deck-list ordering: Main Deck monsters first, then
    // Spell/Trap subtypes; Extra Deck monsters follow Fusion/Synchro/Xyz/Link.
    private fun sortDeckCards(source: List<DeckCard>, extra: Boolean): List<DeckCard> {
        fun category(card: DeckCard): Int {
            val t = card.type.lowercase(java.util.Locale.ROOT)
            if (extra) return when {
                t.contains("fusion") || t.contains("융합") -> 0
                t.contains("synchro") || t.contains("싱크로") -> 1
                t.contains("xyz") || t.contains("엑시즈") -> 2
                t.contains("link") || t.contains("링크") -> 3
                else -> 4
            }
            if (t.contains("spell") || t.contains("마법")) return when {
                t.contains("ritual") || t.contains("의식") -> 11
                t.contains("continuous") || t.contains("지속") -> 12
                t.contains("equip") || t.contains("장착") -> 13
                t.contains("field") || t.contains("필드") -> 14
                t.contains("quick-play") || t.contains("속공") -> 15
                else -> 10 // Normal Spell
            }
            if (t.contains("trap") || t.contains("함정")) return when {
                t.contains("continuous") || t.contains("지속") -> 21
                t.contains("counter") || t.contains("카운터") -> 22
                else -> 20 // Normal Trap
            }
            return when {
                t.contains("normal") || t.contains("일반") -> 0
                t.contains("ritual") || t.contains("의식") -> 2
                else -> 1 // Effect and other Main Deck monsters
            }
        }
        fun levelValue(card: DeckCard): Int = card.level.toIntOrNull() ?: 99
        return source.sortedWith(compareBy<DeckCard> { category(it) }
            .thenBy { levelValue(it) }
            .thenBy { displayCardName(it).lowercase(java.util.Locale.ROOT) })
    }

    // Group by normalized card name and deck section, so duplicate copies occupy one row.
    private fun groupedCards(sectionCards: List<DeckCard>): List<Pair<DeckCard, Int>> {
        val groups = linkedMapOf<String, MutableList<DeckCard>>()
        for (card in sectionCards) {
            val key = normalizedCardName(card.name)
            groups.getOrPut(key) { mutableListOf() }.add(card)
        }
        return groups.values.map { it.first() to it.size }
    }

    private fun addDeckRow(card: DeckCard, count: Int, section: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }
        val image = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        row.addView(image, LinearLayout.LayoutParams(dp(28), dp(38)))
        val baseName = displayCardName(card)
        val displayName = if (count > 1) "$baseName ×$count" else baseName
        val nameView = label(displayName, 12f)
        nameView.setOnClickListener { showCardDetails(card) }
        nameView.setOnLongClickListener { showCardDetails(card); true }
        row.setOnClickListener { showCardDetails(card) }
        row.addView(nameView, LinearLayout.LayoutParams(0, dp(38), 1f))

        val totalInSection = cards.count { it.section == section }
        val sectionLimit = if (section == "MAIN") 60 else 15
        val normalizedName = normalizedCardName(card.name)
        val sameNameCount = cards.count {
            normalizedCardName(it.name) == normalizedName
        }
        if (count < cardLimit(card) && totalInSection < sectionLimit && sameNameCount < cardLimit(card)) {
            row.addView(Button(this).apply {
                text = "+"
                contentDescription = "${card.name} 한 장 추가"
                setOnClickListener { addCard(card) }
            }, LinearLayout.LayoutParams(dp(44), dp(36)))
        }
        row.addView(Button(this).apply {
            text = "−"
            contentDescription = "${card.name} 한 장 제거"
            setOnClickListener {
                val index = cards.indexOfFirst {
                    it.section == section && it.name.trim().replace(Regex("\\s+"), " ")
                        .equals(card.name.trim().replace(Regex("\\s+"), " "), ignoreCase = true)
                }
                if (index >= 0) cards.removeAt(index)
                renderDeck()
            }
        }, LinearLayout.LayoutParams(dp(44), dp(36)))
        deckList.addView(row, LinearLayout.LayoutParams(-1, dp(42)))
        loadImage(card.image, image, card.id)
    }
    private fun showCardDetails(card: DeckCard) {
        val title = displayCardName(card)
        val info = buildString {
            append(KoreanCardNames.koreanType(card.type))
            if (card.level.isNotBlank()) append(" · 레벨/랭크/링크 ${card.level}")
            append("\n\n")
            append(card.effect.ifBlank { "등록된 효과 텍스트가 없습니다." })
        }
        val body = TextView(this).apply {
            text = info
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(dp(18), dp(12), dp(18), dp(12))
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply { addView(body) }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(scroll)
            .setPositiveButton("닫기", null)
            .show()
    }

    private fun saveDeck() { val main=cards.count{it.section=="MAIN"};val extra=cards.count{it.section=="EXTRA"}; if(cards.isNotEmpty()&&main<40){AlertDialog.Builder(this).setMessage("메인 덱은 최소 40장이어야 합니다. 현재 $main 장입니다.\n현재 구성은 저장할 수 있지만 완성 덱으로 표시되지는 않습니다.").setPositiveButton("저장"){_,_->DeckRepository.save(this,cards);toast("덱을 저장했습니다.")}.setNegativeButton("취소",null).show();return}; if(extra>15||main>60){toast("덱 장수 제한을 확인하세요.");return}; DeckRepository.save(this,cards); toast("덱을 저장했습니다. 게임 중 오버레이의 ‘덱’ 버튼으로 확인할 수 있어요.") }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
