plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.masterduelcointracker"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.masterduelcointracker"
        minSdk = 26
        targetSdk = 33
        versionCode = 69
        versionName = "1.1.4.47-diagnostic-candidates"
    }
    signingConfigs {
        create("stableDebug") {
            storeFile = rootProject.file("mdtracker-signing.keystore")
            storePassword = "mdtracker_local_2026"
            keyAlias = "mdtracker"
            keyPassword = "mdtracker_local_2026"
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("stableDebug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.google.mlkit:text-recognition-korean:16.0.1")
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
