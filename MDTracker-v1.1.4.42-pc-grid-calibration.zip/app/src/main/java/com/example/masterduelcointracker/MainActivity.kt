package com.example.masterduelcointracker

import android.app.Activity
import android.app.AlertDialog
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.content.pm.PackageManager
import android.provider.Settings
import android.app.AppOpsManager
import android.content.Context
import android.os.Process
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val captureRequestCode = 7021
    private var flowStarted = false
    private var notificationPromptedThisLaunch = false
    private var waitingForUsageAccess = false
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (waitingForUsageAccess) {
            waitingForUsageAccess = false
            if (hasUsageAccess()) {
                showAutoRecognitionDialog()
            } else {
                AlertDialog.Builder(this)
                    .setTitle("게임 화면 인식 권한")
                    .setMessage("사용 정보 접근 권한이 허용되지 않았어요. 이 권한 없이는 다른 앱의 스크린샷과 마스터 듀얼 화면을 구분할 수 없습니다.")
                    .setPositiveButton("다시 설정") { _, _ ->
                        waitingForUsageAccess = true
                        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:$packageName")))
                    }
                    .setNegativeButton("계속") { _, _ -> showAutoRecognitionDialog() }
                    .show()
            }
        }
    }


    private fun beginStartupFlow() {
        if (flowStarted) return
        flowStarted = true
        // Ask for notification permission only after overlay permission has been granted.
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
            !notificationPromptedThisLaunch) {
            notificationPromptedThisLaunch = true
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 7023)
            return
        }
        continueAfterNotificationPermission()
    }

    private fun continueAfterNotificationPermission() {
        if (!hasUsageAccess()) {
            AlertDialog.Builder(this)
                .setTitle("게임 화면 인식 권한")
                .setMessage("마스터 듀얼이 실제로 화면에 열려 있을 때만 코인과 승패를 인식하려면 사용 정보 접근 권한이 필요합니다. 이 권한이 없으면 자동 인식은 게임 앱이 앞에 있을 때로 제한할 수 없습니다.")
                .setPositiveButton("설정 열기") { _, _ ->
                    waitingForUsageAccess = true
                    try {
                        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:$packageName")))
                    } catch (_: Exception) {
                        waitingForUsageAccess = false
                        showAutoRecognitionDialog()
                    }
                }
                .setNegativeButton("이번에는 건너뛰기") { _, _ -> showAutoRecognitionDialog() }
                .show()
            return
        }
        showAutoRecognitionDialog()
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = appOps.checkOpNoThrow("android:get_usage_stats", Process.myUid(), packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun showAutoRecognitionDialog() {
        AlertDialog.Builder(this)
            .setTitle("자동 인식")
            .setMessage("이번 실행에서 자동 인식을 사용할까요?\n\n예: 화면 캡처 권한을 확인한 뒤 자동 인식을 시작합니다.\n아니요: 자동 인식 없이 기록 창만 표시합니다.")
            .setPositiveButton("예") { _, _ -> startAutomaticRecognition() }
            .setNegativeButton("아니요") { _, _ ->
                // 자동 인식을 거절하면 오버레이를 띄우지 않고 앱 화면에 머문다.
                render()
            }
            .setOnCancelListener {
                // 대화상자를 닫은 경우에도 기록 오버레이를 자동으로 띄우지 않는다.
                render()
            }
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7023) continueAfterNotificationPermission()
    }

    private fun startAutomaticRecognition() {
        if (!hasUsageAccess()) {
            waitingForUsageAccess = true
            AlertDialog.Builder(this)
                .setTitle("게임 화면 인식 권한 필요")
                .setMessage("마스터 듀얼 화면에서만 기록하려면 사용 정보 접근 권한이 필요합니다. 설정에서 MD 트래커를 허용해 주세요.")
                .setPositiveButton("설정 열기") { _, _ ->
                    try {
                        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:$packageName")))
                    } catch (_: Exception) {
                        waitingForUsageAccess = false
                        Toast.makeText(this, "설정을 열 수 없어요.", Toast.LENGTH_LONG).show()
                    }
                }
                .setNegativeButton("취소") { _, _ -> waitingForUsageAccess = false }
                .show()
            return
        }
        showOverlayAndReturn()
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequestCode)
    }

    private fun showOverlayAndReturn() {
        startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_SHOW))
        moveTaskToBack(true)
    }

    @Deprecated("Deprecated API retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequestCode) {
            if (resultCode == RESULT_OK && data != null) {
                val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_START
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
                else startService(serviceIntent)
                Toast.makeText(this, "자동 인식을 시작했어요.", Toast.LENGTH_LONG).show()
                moveTaskToBack(true)
            } else {
                Toast.makeText(this, "화면 캡처 권한이 허용되지 않아 자동 인식을 시작하지 않았어요.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun openThisAppOverlaySettings() {
        val appSpecific = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        try {
            startActivity(appSpecific)
        } catch (_: Exception) {
            // On customized Android settings, fall back to this app's own details page.
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }


    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(0xFFF4F5F7.toInt())
        }
        val title = TextView(this).apply {
            text = "MD 트래커"
            textSize = 24f
            setTextColor(0xFF172033.toInt())
            gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "마스터 듀얼의 코인 결과와 승패를 기록하고, 필요할 때 자동 인식을 시작할 수 있어요.\n\n기록은 이 기기에 저장됩니다."
            textSize = 16f
            setTextColor(0xFF3F4756.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(22))
        }
        val autoStart = Button(this).apply {
            text = "자동 인식 시작"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    flowStarted = false
                    openThisAppOverlaySettings()
                } else startAutomaticRecognition()
            }
        }
        val deckBuilder = Button(this).apply {
            text = "덱 빌더 열기"
            setOnClickListener { startActivity(Intent(this@MainActivity, DeckActivity::class.java)) }
        }
        val autoStop = Button(this).apply {
            text = "자동 인식 중지"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenCaptureService::class.java))
                Toast.makeText(this@MainActivity, "자동 인식을 중지했어요.", Toast.LENGTH_SHORT).show()
            }
        }
        listOf(title, desc, autoStart, deckBuilder, autoStop).forEachIndexed { i, view ->
            root.addView(view, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                if (i < 2) ViewGroup.LayoutParams.WRAP_CONTENT else dp(52)
            ).apply { if (i >= 2) topMargin = dp(8) })
        }
        setContentView(root)
        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle("오버레이 권한")
                .setMessage("기록 창을 다른 앱 위에 표시하려면 권한이 필요합니다. 지금 허용할까요?")
                .setPositiveButton("설정 열기") { _, _ ->
                    openThisAppOverlaySettings()
                }
                .setNegativeButton("나중에", null)
                .show()
        }
    }
}
