package com.example.masterduelcointracker

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Offline, deterministic 192-D artwork descriptor.
 * 128 HOG bins (4x4 cells x 8 orientations) + 48 HSV histogram bins
 * (16 each for H/S/V) + 16 coarse luminance layout values.
 * This is a handcrafted visual embedding, not a neural-network embedding.
 */
internal object ArtworkVectorizer {
    private const val SIZE = 64
    private const val DIM = 192

    fun extract(source: Bitmap): FloatArray {
        val scaled = Bitmap.createScaledBitmap(source, SIZE, SIZE, true)
        val pixels = IntArray(SIZE * SIZE)
        scaled.getPixels(pixels, 0, SIZE, 0, 0, SIZE, SIZE)
        if (scaled !== source) scaled.recycle()

        val gray = FloatArray(SIZE * SIZE)
        val hsv = FloatArray(3)
        val vector = FloatArray(DIM)
        val hue = FloatArray(16)
        val sat = FloatArray(16)
        val value = FloatArray(16)
        val lumCells = FloatArray(16)
        val lumCounts = IntArray(16)

        for (y in 0 until SIZE) for (x in 0 until SIZE) {
            val c = pixels[y * SIZE + x]
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            gray[y * SIZE + x] = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
            Color.RGBToHSV(r, g, b, hsv)
            val hi = (hsv[0] / 360f * 16f).toInt().coerceIn(0, 15)
            val si = (hsv[1] * 16f).toInt().coerceIn(0, 15)
            val vi = (hsv[2] * 16f).toInt().coerceIn(0, 15)
            hue[hi] += 1f; sat[si] += 1f; value[vi] += 1f
            val cell = (y / 16) * 4 + (x / 16)
            lumCells[cell] += gray[y * SIZE + x]
            lumCounts[cell]++
        }

        // HOG: unsigned gradient orientation, 8 bins, in 4x4 spatial cells.
        for (y in 1 until SIZE - 1) for (x in 1 until SIZE - 1) {
            val gx = gray[y * SIZE + x + 1] - gray[y * SIZE + x - 1]
            val gy = gray[(y + 1) * SIZE + x] - gray[(y - 1) * SIZE + x]
            val mag = sqrt(gx * gx + gy * gy)
            if (mag < 0.015f) continue
            var angle = Math.toDegrees(kotlin.math.atan2(gy.toDouble(), gx.toDouble())).toFloat()
            if (angle < 0f) angle += 180f
            if (angle >= 180f) angle -= 180f
            val bin = (angle / 22.5f).toInt().coerceIn(0, 7)
            val cell = (y / 16) * 4 + (x / 16)
            vector[cell * 8 + bin] += mag
        }

        var offset = 128
        for (hist in arrayOf(hue, sat, value)) {
            val sum = hist.sum().coerceAtLeast(1f)
            for (i in 0 until 16) vector[offset + i] = hist[i] / sum
            offset += 16
        }
        for (i in 0 until 16) vector[176 + i] = lumCells[i] / lumCounts[i].coerceAtLeast(1)

        // L2-normalize HOG and the complete descriptor to make cosine comparison stable.
        normalizeRange(vector, 0, 128)
        normalizeRange(vector, 128, 64)
        val norm = sqrt(vector.sumOf { (it * it).toDouble() }).toFloat().coerceAtLeast(1e-8f)
        for (i in vector.indices) vector[i] /= norm
        return vector
    }

    private fun normalizeRange(v: FloatArray, start: Int, length: Int) {
        var sum = 0f
        for (i in start until start + length) sum += v[i] * v[i]
        val norm = sqrt(sum).coerceAtLeast(1e-8f)
        for (i in start until start + length) v[i] /= norm
    }
}
