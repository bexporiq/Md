package com.example.masterduelcointracker

import android.content.Context
import java.io.DataInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Full-catalog visual lookup. The generated asset is built by tools/build_artwork_vector_catalog.py. */
internal object ArtworkCatalogIndex {
    private const val MAGIC = "MDAV2\u0000\u0000\u0000"
    private const val DIM = 192
    data class Entry(val cardId: Int, val artworkId: Int, val vector: FloatArray)
    @Volatile private var cached: List<Entry>? = null

    fun entries(context: Context): List<Entry> {
        cached?.let { return it }
        synchronized(this) {
            cached?.let { return it }
            val parsed = runCatching {
                val bytes = context.assets.open("artwork_vectors_v1.bin").use { it.readBytes() }
                require(bytes.size >= 12)
                val b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                val magic = ByteArray(8); b.get(magic)
                require(String(magic, Charsets.US_ASCII) == MAGIC)
                val count = b.int
                require(count >= 0 && bytes.size.toLong() == 12L + count.toLong() * (6L + DIM * 4L))
                List(count) {
                    val id = b.int
                    val art = b.short.toInt()
                    val vector = FloatArray(DIM) { b.float }
                    Entry(id, art, vector)
                }
            }.getOrDefault(emptyList())
            cached = parsed
            return parsed
        }
    }

    data class RankedCandidate(val cardId: Int, val score: Int)
    data class TileDiagnostic(val tileIndex: Int, val topCandidates: List<RankedCandidate>)
    data class IdentificationResult(
        val matches: Map<Int, Pair<Int, Int>>,
        val diagnostics: List<TileDiagnostic>
    )

    /** Match each illustration and retain the three best candidates for diagnostics. */
    fun identifyDetailed(context: Context, tiles: List<FloatArray>, minimumScore: Int = 72): IdentificationResult {
        val catalog = entries(context)
        if (catalog.isEmpty()) return IdentificationResult(emptyMap(), emptyList())
        val totals = linkedMapOf<Int, Pair<Int, Int>>() // id -> (quantity, best score)
        val diagnostics = ArrayList<TileDiagnostic>(tiles.size)
        for ((tileIndex, tile) in tiles.withIndex()) {
            var bestId = 0; var best = -1f
            val perCard = HashMap<Int, Float>()
            for (entry in catalog) {
                if (tile.size != DIM) continue
                var dot = 0f
                for (i in 0 until DIM) dot += tile[i] * entry.vector[i]
                if (dot > (perCard[entry.cardId] ?: -1f)) perCard[entry.cardId] = dot
            }
            val ranked = perCard.entries
                .sortedByDescending { it.value }
                .take(3)
                .map { RankedCandidate(it.key, (it.value.coerceIn(0f, 1f) * 100f).toInt()) }
            diagnostics += TileDiagnostic(tileIndex + 1, ranked)
            val first = ranked.firstOrNull()
            if (first != null) {
                bestId = first.cardId
                best = first.score / 100f
            }
            val percent = (best.coerceIn(0f, 1f) * 100f).toInt()
            if (bestId > 0 && percent >= minimumScore) {
                val old = totals[bestId]
                totals[bestId] = ((old?.first ?: 0) + 1) to maxOf(old?.second ?: 0, percent)
            }
        }
        return IdentificationResult(totals, diagnostics)
    }

}
