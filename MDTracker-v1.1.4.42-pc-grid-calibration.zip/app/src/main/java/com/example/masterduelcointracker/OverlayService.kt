package com.example.masterduelcointracker

import android.app.Service
import android.app.AlertDialog
import android.widget.PopupMenu
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    companion object {
        const val ACTION_SHOW = "com.example.masterduelcointracker.SHOW"
        const val ACTION_REFRESH = "com.example.masterduelcointracker.REFRESH"
        const val PREFS = "coin_tracker"
    }

    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var collapsed = false
    private var heads = 0
    private var tails = 0
    private var wins = 0
    private var losses = 0
    private var last: String? = null
    private var summary: TextView? = null
    private var expandedContent: LinearLayout? = null
    private val refreshHandler = Handler(Looper.getMainLooper())
    private val syncRunnable = object : Runnable {
        override fun run() {
            if (panel != null) {
                val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
                heads = prefs.getInt("heads", heads)
                tails = prefs.getInt("tails", tails)
                wins = prefs.getInt("game_wins", wins)
                losses = prefs.getInt("game_losses", losses)
                last = prefs.getString("last", "")?.takeIf { it == "H" || it == "T" }
                refresh()
                refreshHandler.postDelayed(this, 1000)
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val p = getSharedPreferences(PREFS, MODE_PRIVATE)
        heads = p.getInt("heads", 0)
        tails = p.getInt("tails", 0)
        wins = p.getInt("game_wins", 0)
        losses = p.getInt("game_losses", 0)
        last = p.getString("last", "").takeIf { it == "H" || it == "T" }
        showPanel()
        refreshHandler.postDelayed(syncRunnable, 1000)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showPanel()
        return START_STICKY
    }

    private fun save() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putInt("heads", heads).putInt("tails", tails)
            .putString("last", last ?: "").apply()
    }

    private fun text(value: String, size: Float = 14f): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }

    private fun button(label: String, action: (View) -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            setOnClickListener { clickedView -> action(clickedView) }
        }

    private fun showPanel() {
        if (panel != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            setBackgroundColor(0xEE172033.toInt())
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = text("🪙 대전 기록", 15f).apply {
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(8), 0)
        }
        val collapse = button("접기") { toggleCollapse() }
        val menu = button("⋮") { clickedView -> showOptions(clickedView) }
        val deck = button("덱") { startService(Intent(this, DeckOverlayService::class.java)) }
        val close = button("중단") { confirmStopRecognition() }
        header.addView(title, LinearLayout.LayoutParams(0, dp(42), 1f))
        header.addView(menu, LinearLayout.LayoutParams(dp(42), dp(42)))
        header.addView(deck, LinearLayout.LayoutParams(dp(44), dp(42)))
        header.addView(collapse, LinearLayout.LayoutParams(dp(62), dp(42)))
        header.addView(close, LinearLayout.LayoutParams(dp(62), dp(42)))
        root.addView(header)

        summary = text("", 13f).apply { setPadding(0, dp(4), 0, dp(4)) }
        root.addView(summary, LinearLayout.LayoutParams(-1, dp(72)))

        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        expandedContent = content
        root.addView(content)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            dp(280), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(24); y = dp(120)
        }
        params = lp
        // Drag the panel by touching the title area.
        title.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x; startY = lp.y
                        touchX = event.rawX; touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = startX + (event.rawX - touchX).toInt()
                        lp.y = startY + (event.rawY - touchY).toInt()
                        try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
                        return true
                    }
                }
                return false
            }
        })
        panel = root
        try {
            wm.addView(root, lp)
            refresh()
        } catch (_: Exception) {
            panel = null
            stopSelf()
        }
    }

    private fun showOptions(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add("코인 기록 초기화").setOnMenuItemClickListener {
            confirmResetRecords(
                title = "코인 기록 초기화",
                message = "선공·후공 기록만 초기화할까요? 게임 승패 기록은 유지됩니다.",
                positiveLabel = "코인 기록 초기화"
            ) {
                heads = 0
                tails = 0
                last = null
                save()
                refresh()
            }
            true
        }
        popup.menu.add("게임 기록 초기화").setOnMenuItemClickListener {
            confirmResetRecords(
                title = "게임 기록 초기화",
                message = "게임 승·패 기록만 초기화할까요? 코인 기록은 유지됩니다.",
                positiveLabel = "게임 기록 초기화"
            ) {
                wins = 0
                losses = 0
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putInt("game_wins", 0)
                    .putInt("game_losses", 0)
                    .apply()
                refresh()
            }
            true
        }
        popup.show()
    }

    private fun confirmResetRecords(
        title: String,
        message: String,
        positiveLabel: String,
        onConfirm: () -> Unit
    ) {
        // Use a confirmation panel owned by WindowManager instead of AlertDialog.
        // AlertDialog can crash when launched from a TYPE_APPLICATION_OVERLAY service
        // because its token/window type is not reliably accepted on all Android builds.
        val dialogRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(16), dp(18), dp(12))
            setBackgroundColor(0xFF263247.toInt())
            elevation = dp(12).toFloat()
        }
        val titleView = text(title, 17f).apply {
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(10))
        }
        val messageView = text(message, 14f).apply {
            setPadding(dp(4), dp(4), dp(4), dp(14))
        }
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val cancel = button("취소") { _ ->
            try { wm.removeView(dialogRoot) } catch (_: Exception) {}
        }
        val confirm = button(positiveLabel) { _ ->
            try { wm.removeView(dialogRoot) } catch (_: Exception) {}
            onConfirm()
            refresh()
        }
        actions.addView(cancel, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(confirm, LinearLayout.LayoutParams(0, dp(48), 1f))
        dialogRoot.addView(titleView)
        dialogRoot.addView(messageView)
        dialogRoot.addView(actions)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val dialogParams = WindowManager.LayoutParams(
            dp(300), WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }
        try {
            wm.addView(dialogRoot, dialogParams)
        } catch (_: Exception) {
            android.widget.Toast.makeText(
                this,
                "확인창을 표시하지 못했어요. 오버레이 권한을 확인해 주세요.",
                android.widget.Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun confirmStopRecognition() {
        val dialog = AlertDialog.Builder(this)
            .setTitle("기록 중단")
            .setMessage("자동 인식을 중단하고 기록 창을 닫을까요? 누적 기록은 기기에 저장됩니다.")
            .setNegativeButton("취소", null)
            .setPositiveButton("중단") { _, _ ->
                // Explicitly stop OCR and immediately remove the overlay before stopping this service.
                // Counts remain in SharedPreferences.
                stopService(Intent(this, ScreenCaptureService::class.java))
                refreshHandler.removeCallbacks(syncRunnable)
                val currentPanel = panel
                if (currentPanel != null) {
                    try { wm.removeView(currentPanel) } catch (_: Exception) {}
                }
                panel = null
                stopSelf()
            }
            .create()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        }
        dialog.show()
    }

    private fun toggleCollapse() {
        collapsed = !collapsed
        expandedContent?.visibility = if (collapsed) View.GONE else View.VISIBLE
        val p = panel ?: return
        val header = p.getChildAt(0) as LinearLayout
        val btn = header.getChildAt(2) as Button
        btn.text = if (collapsed) "펼치기" else "접기"
        summary?.visibility = if (collapsed) View.GONE else View.VISIBLE
        params?.let { try { wm.updateViewLayout(p, it) } catch (_: Exception) {} }
    }

    private fun refresh() {
        val total = heads + tails
        val pct = if (total == 0) 0.0 else heads * 100.0 / total
        val games = wins + losses
        val winPct = if (games == 0) 0.0 else wins * 100.0 / games
        summary?.text = "선공 $heads  ·  후공 $tails\n총 ${total}회  |  선공 ${"%.1f".format(java.util.Locale.KOREA, pct)}%\n게임 승률  ${wins}승 ${losses}패  |  ${"%.1f".format(java.util.Locale.KOREA, winPct)}%"
    }

    override fun onDestroy() {
        refreshHandler.removeCallbacks(syncRunnable)
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
