package com.example.masterduelcointracker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class DeckCard(
    val id: Int,
    val name: String,
    val image: String,
    val type: String,
    val section: String,
    val localizedName: String = "",
    val effect: String = "",
    val level: String = ""
)

object DeckRepository {
    private const val PREFS = "md_deck_builder"
    private const val KEY = "cards"
    fun load(context: Context): MutableList<DeckCard> {
        val out = mutableListOf<DeckCard>()
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(DeckCard(
                    o.optInt("id"), o.optString("name"), o.optString("image"),
                    o.optString("type"), o.optString("section", "MAIN"),
                    o.optString("localizedName"), o.optString("effect"), o.optString("level")
                ))
            }
        } catch (_: Exception) {}
        return out
    }
    fun save(context: Context, cards: List<DeckCard>) {
        val arr = JSONArray()
        cards.forEach { c -> arr.put(JSONObject().put("id", c.id).put("name", c.name).put("image", c.image).put("type", c.type).put("section", c.section)
            .put("localizedName", c.localizedName).put("effect", c.effect).put("level", c.level)) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
    fun imageUrl(card: DeckCard): String = card.image
}
