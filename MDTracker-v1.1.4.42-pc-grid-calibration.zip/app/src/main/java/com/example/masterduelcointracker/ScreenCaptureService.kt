package com.example.masterduelcointracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.os.Process
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.android.gms.tasks.Tasks
import java.util.Locale

class ScreenCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.example.masterduelcointracker.CAPTURE_START"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "coin_tracker_capture"
        private const val NOTIFICATION_ID = 7022
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var worker: HandlerThread? = null
    private var workerHandler: Handler? = null
    // The result screen mixes Korean surrender text with the Latin VICTORY/DEFEAT title.
    // Run both script recognizers on each captured frame and merge their OCR text.
    private val koreanRecognizer by lazy {
        TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
    }
    private val latinRecognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }
    @Volatile private var processing = false
    private var outcomeAlreadyRecorded = false
    private var missingOutcomeFrames = 0
    private var gameResultAlreadyRecorded = false
    private var missingGameResultFrames = 0
    private var stoppingCapture = false
    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            if (!stoppingCapture) {
                stopCapture()
                stopSelf()
            }
        }
    }
    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForegroundCompat()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START) {
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
            @Suppress("DEPRECATION")
            val data = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            } else {
                intent.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent
            }
            if (data != null) startCapture(resultCode, data) else stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        @Suppress("DEPRECATION")
        val builder: Notification.Builder = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        val notification: Notification = builder
            .setContentTitle("MD 코인 기록")
            .setContentText("게임 화면에서 선공·후공 및 승패를 자동으로 인식 중")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID, "화면 자동 인식", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "마스터 듀얼 결과를 인식하기 위한 화면 캡처 알림" }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        if (projection != null) return
        try {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            screenWidth = metrics.widthPixels
            screenHeight = metrics.heightPixels
            screenDensity = metrics.densityDpi

            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            worker = HandlerThread("CoinOCR").also { it.start() }
            workerHandler = Handler(worker!!.looper)

            // RGBA makes bitmap conversion straightforward. Two buffers are sufficient because
            // OCR is serialized and each Image is closed immediately after conversion.
            imageReader = ImageReader.newInstance(
                screenWidth, screenHeight, PixelFormat.RGBA_8888, 2
            ).also { reader ->
                reader.setOnImageAvailableListener({ source ->
                    val image = try { source.acquireLatestImage() } catch (_: Exception) { null }
                    if (image == null) return@setOnImageAvailableListener
                    if (processing) {
                        image.close()
                        return@setOnImageAvailableListener
                    }
                    processing = true
                    val bitmap = try { imageToBitmap(image) } catch (_: Exception) { null }
                    image.close()
                    if (bitmap == null) {
                        processing = false
                        return@setOnImageAvailableListener
                    }
                    try {
                        val input = InputImage.fromBitmap(bitmap, 0)
                        val koreanTask = koreanRecognizer.process(input)
                        val latinTask = latinRecognizer.process(input)
                        Tasks.whenAllComplete(koreanTask, latinTask)
                            .addOnCompleteListener {
                                // whenAllComplete returns heterogeneous Task<*> values. Read
                                // each recognizer's typed result directly instead of accessing
                                // `text` through the untyped completedTasks collection.
                                val koreanText: String = if (koreanTask.isSuccessful) {
                                    koreanTask.result?.text.orEmpty()
                                } else ""
                                val latinText: String = if (latinTask.isSuccessful) {
                                    latinTask.result?.text.orEmpty()
                                } else ""
                                val combinedText = listOf(koreanText, latinText)
                                    .filter { it.isNotBlank() }
                                    .joinToString("\n")
                                if (combinedText.isNotBlank()) processRecognizedText(combinedText)
                                if (!bitmap.isRecycled) bitmap.recycle()
                                processing = false
                            }
                    } catch (_: Exception) {
                        if (!bitmap.isRecycled) bitmap.recycle()
                        processing = false
                    }
                }, workerHandler)
            }

            projection?.registerCallback(projectionCallback, workerHandler)

            virtualDisplay = projection?.createVirtualDisplay(
                "MasterDuelCoinTrackerCapture",
                screenWidth, screenHeight, screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface, null, workerHandler
            )
        } catch (_: Exception) {
            stopCapture()
            stopSelf()
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val paddedWidth = rowStride / pixelStride
        val paddedBitmap = Bitmap.createBitmap(
            paddedWidth, image.height, Bitmap.Config.ARGB_8888
        )
        buffer.rewind()
        paddedBitmap.copyPixelsFromBuffer(buffer)
        val result = Bitmap.createBitmap(paddedBitmap, 0, 0, image.width, image.height)
        paddedBitmap.recycle()
        return result
    }

    private fun processRecognizedText(rawText: String) {
        // Never inspect text for counters unless Master Duel is the foreground app.
        if (!isMasterDuelForeground()) {
            missingOutcomeFrames++
            missingGameResultFrames++
            if (missingOutcomeFrames >= 3) outcomeAlreadyRecorded = false
            if (missingGameResultFrames >= 5) gameResultAlreadyRecorded = false
            return
        }
        val text = rawText.lowercase(Locale.ROOT)
            .replace(Regex("\\s+"), "")
            .replace("。", "")
            .replace(".", "")

        // Korean Master Duel coin announcement: read the sentence, not the mascot/artwork.
        // The supplied screenshots show "당신이 선공입니다." and "당신이 후공입니다.".
        val compactText = rawText.lowercase(Locale.ROOT)
            .replace(Regex("\\s+"), "")
            .replace(Regex("[.!?,:;·。]"), "")
        val firstPhrases = listOf("당신이선공입니다", "당신은선공입니다", "선공입니다")
        val secondPhrases = listOf("당신이후공입니다", "당신은후공입니다", "후공입니다")
        val heads = firstPhrases.any { compactText.contains(it) }
        val tails = secondPhrases.any { compactText.contains(it) }
        // Only count if exactly one direction is found; ambiguous OCR is ignored.
        val outcome = when {
            heads && !tails -> "H"
            tails && !heads -> "T"
            else -> null
        }
        if (outcome != null) {
            missingOutcomeFrames = 0
            if (!outcomeAlreadyRecorded) {
                outcomeAlreadyRecorded = true
                recordOutcome(outcome)
            }
        } else {
            missingOutcomeFrames++
            if (missingOutcomeFrames >= 3) outcomeAlreadyRecorded = false
        }

        // Result screens contain VICTORY/DEFEAT and a Korean surrender sentence.
        // Match the title and the corresponding sentence, not incidental card text.
        val victory = text.contains("victory")
        val defeat = text.contains("defeat")
        val opponentSurrendered = text.contains("상대가항복했습니다")
        val selfSurrendered = text.contains("상대에게항복했습니다")
        val gameResult = when {
            (victory || opponentSurrendered) && !(defeat || selfSurrendered) -> "W"
            (defeat || selfSurrendered) && !(victory || opponentSurrendered) -> "L"
            else -> null
        }
        if (gameResult != null) {
            missingGameResultFrames = 0
            if (!gameResultAlreadyRecorded) {
                gameResultAlreadyRecorded = true
                recordGameResult(gameResult)
            }
        } else {
            missingGameResultFrames++
            if (missingGameResultFrames >= 5) gameResultAlreadyRecorded = false
        }
    }

    private fun isMasterDuelForeground(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        if (appOps.checkOpNoThrow("android:get_usage_stats", Process.myUid(), packageName) != AppOpsManager.MODE_ALLOWED) {
            return false
        }
        val manager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        // Replay a sufficiently long event history. A 15-second window loses the
        // ACTIVITY_RESUMED event when the player has been in Master Duel for a while.
        val events = manager.queryEvents(end - 24L * 60L * 60L * 1000L, end)
        val event = UsageEvents.Event()
        var foregroundPackage: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            val foreground = if (Build.VERSION.SDK_INT >= 29) {
                event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
            } else {
                @Suppress("DEPRECATION")
                event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
            }
            val background = if (Build.VERSION.SDK_INT >= 29) {
                event.eventType == UsageEvents.Event.ACTIVITY_PAUSED
            } else {
                @Suppress("DEPRECATION")
                event.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND
            }
            if (foreground) foregroundPackage = event.packageName
            if (background && foregroundPackage == event.packageName) foregroundPackage = null
        }
        return foregroundPackage in setOf(
            "jp.konami.masterduel",
            "com.konami.masterduel",
            "com.konami.masterduel.global"
        )
    }

    private fun containsAny(text: String, phrases: List<String>): Boolean =
        phrases.any { text.contains(it) }

    private fun recordOutcome(outcome: String) {
        val prefs = getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE)
        val key = if (outcome == "H") "heads" else "tails"
        prefs.edit().putInt(key, prefs.getInt(key, 0) + 1)
            .putString("last", outcome).apply()
        val refreshIntent = Intent(OverlayService.ACTION_REFRESH)
        refreshIntent.setPackage(packageName)
        sendBroadcast(refreshIntent)
    }


    private fun recordGameResult(result: String) {
        val prefs = getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE)
        val key = if (result == "W") "game_wins" else "game_losses"
        prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply()
        val refreshIntent = Intent(OverlayService.ACTION_REFRESH).apply { setPackage(packageName) }
        sendBroadcast(refreshIntent)
    }

    private fun stopCapture() {
        if (stoppingCapture) return
        stoppingCapture = true
        val oldProjection = projection
        projection = null
        try { oldProjection?.unregisterCallback(projectionCallback) } catch (_: Exception) {}
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try { imageReader?.setOnImageAvailableListener(null, null) } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        imageReader = null
        try { oldProjection?.stop() } catch (_: Exception) {}
        try { worker?.quitSafely() } catch (_: Exception) {}
        worker = null
        workerHandler = null
        try { koreanRecognizer.close() } catch (_: Exception) {}
        try { latinRecognizer.close() } catch (_: Exception) {}
        stoppingCapture = false
    }

    override fun onDestroy() {
        stopCapture()
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE)
        else stopForeground(true)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
