package com.example.masterduelcointracker

import android.app.Service
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class DeckOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private val executor=Executors.newSingleThreadExecutor()
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    override fun onBind(intent:Intent?):IBinder?=null
    override fun onCreate(){super.onCreate();wm=getSystemService(WINDOW_SERVICE) as WindowManager;show()}
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {if(root==null)show();return START_NOT_STICKY}
    private fun show(){
        val all=DeckRepository.load(this); val main=all.filter{it.section=="MAIN"};val extra=all.filter{it.section=="EXTRA"}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(6),dp(8),dp(8));setBackgroundColor(0xF21B2433.toInt())}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val title=TextView(this).apply{text="📚 덱 레시피 (${main.size}+${extra.size})";textSize=15f;setTextColor(Color.WHITE);setPadding(dp(4),0,dp(4),0)}
        header.addView(title,LinearLayout.LayoutParams(0,dp(42),1f));header.addView(Button(this).apply{text="닫기";textSize=11f;setOnClickListener{stopSelf()}},LinearLayout.LayoutParams(dp(60),dp(40)));box.addView(header)
        val tabs=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val scroll=ScrollView(this);scroll.addView(content);box.addView(scroll,LinearLayout.LayoutParams(-1,dp(360)))
        fun showSection(which:String){content.removeAllViews();val list=if(which=="MAIN")main else extra;content.addView(TextView(this).apply{text=if(which=="MAIN")"메인 덱 ${main.size}/60" else "엑스트라 덱 ${extra.size}/15";textSize=13f;setTextColor(Color.WHITE);setPadding(dp(4),dp(5),dp(4),dp(5))});list.forEach{card->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(2),dp(2),dp(2),dp(2))}
            val image=ImageView(this).apply{scaleType=ImageView.ScaleType.FIT_CENTER};row.addView(image,LinearLayout.LayoutParams(dp(48),dp(68)))
            row.addView(TextView(this).apply{text=card.name;textSize=12f;setTextColor(Color.WHITE);setPadding(dp(6),0,0,0)},LinearLayout.LayoutParams(0,dp(68),1f));content.addView(row);loadImage(card.image,image)
        };if(list.isEmpty())content.addView(TextView(this).apply{text="저장된 카드가 없습니다. 앱에서 덱을 만들어 저장하세요.";setTextColor(Color.WHITE);textSize=12f})}
        tabs.addView(Button(this).apply{text="메인";setOnClickListener{showSection("MAIN")}},LinearLayout.LayoutParams(0,dp(40),1f));tabs.addView(Button(this).apply{text="엑스트라";setOnClickListener{showSection("EXTRA")}},LinearLayout.LayoutParams(0,dp(40),1f));box.addView(tabs,0);showSection("MAIN")
        val type=if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp=WindowManager.LayoutParams(dp(270),WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.END;x=dp(12);y=dp(110)}
        title.setOnTouchListener(object:View.OnTouchListener{var sx=0;var sy=0;var tx=0f;var ty=0f;override fun onTouch(v:View,e:MotionEvent):Boolean{when(e.action){MotionEvent.ACTION_DOWN->{sx=lp.x;sy=lp.y;tx=e.rawX;ty=e.rawY;return true};MotionEvent.ACTION_MOVE->{lp.x=sx-(e.rawX-tx).toInt();lp.y=sy+(e.rawY-ty).toInt();try{wm.updateViewLayout(box,lp)}catch(_:Exception){};return true}};return false}})
        root=box;try{wm.addView(box,lp)}catch(_:Exception){root=null;stopSelf()}
    }
    private fun loadImage(url:String,target:ImageView){if(url.isBlank())return;executor.execute{try{val c=URL(url).openConnection() as HttpURLConnection;c.connectTimeout=6000;c.readTimeout=6000;val b=c.inputStream.use{BitmapFactory.decodeStream(it)};c.disconnect();if(b!=null)target.post{target.setImageBitmap(b)}}catch(_:Exception){}}}
    override fun onDestroy(){root?.let{try{wm.removeView(it)}catch(_:Exception){}};root=null;executor.shutdownNow();super.onDestroy()}
}
